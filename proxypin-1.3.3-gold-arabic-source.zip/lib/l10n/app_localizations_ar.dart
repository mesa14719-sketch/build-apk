// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get breakpoint => 'نقطة توقف';

  @override
  String get breakpointRule => 'قاعدة نقطة توقف';

  @override
  String get name => 'الاسم';

  @override
  String get requests => 'الطلبات';

  @override
  String get favorites => 'المفضلات';

  @override
  String get history => 'السجل';

  @override
  String get toolbox => 'أدوات';

  @override
  String get preference => 'التفضيلات';

  @override
  String get feedback => 'ملاحظات';

  @override
  String get about => 'حول';

  @override
  String get filter => 'مرشح البروكسي';

  @override
  String get script => 'سكريبت';

  @override
  String get share => 'مشاركة';

  @override
  String get port => 'المنفذ: ';

  @override
  String get proxy => 'بروكسي';

  @override
  String get externalProxy => 'بروكسي خارجي';

  @override
  String get username => 'اسم المستخدم';

  @override
  String get password => 'كلمة المرور';

  @override
  String get proxySetting => 'إعداد البروكسي';

  @override
  String get setAs => 'تعيين كـ ';

  @override
  String get systemProxy => 'بروكسي النظام';

  @override
  String get enabledHTTP2 => 'تمكين HTTP2';

  @override
  String get serverNotStart => 'خادم البروكسي غير قيد التشغيل';

  @override
  String get download => 'تنزيل';

  @override
  String get config => 'التكوين';

  @override
  String get version => 'الإصدار';

  @override
  String get start => 'بدء';

  @override
  String get stop => 'إيقاف';

  @override
  String get clear => 'مسح';

  @override
  String get httpsProxy => 'بروكسي HTTPS';

  @override
  String get setting => 'الإعدادات';

  @override
  String get mobileConnect => 'اتصال الجوال';

  @override
  String get connectRemote => 'الاتصال عن بُعد';

  @override
  String get remoteDevice => 'جهاز بعيد';

  @override
  String get remoteDeviceList => 'قائمة الأجهزة البعيدة';

  @override
  String get myQRCode => 'رمز QR الخاص بي';

  @override
  String get theme => 'السمة';

  @override
  String get followSystem => 'اتباع النظام';

  @override
  String get themeColor => 'لون السمة';

  @override
  String get themeLight => 'فاتح';

  @override
  String get themeDark => 'داكن';

  @override
  String get language => 'اللغة';

  @override
  String get autoStartup => 'بدء تسجيل حركة المرور تلقائيًا';

  @override
  String get autoStartupDescribe => 'بدء تسجيل حركة المرور تلقائيًا عند تشغيل البرنامج';

  @override
  String get minimizeToTrayTitle => 'تصغير إلى علبة النظام عند الإغلاق';

  @override
  String get minimizeToTraySubtitle => 'إغلاق النافذة سيبقي ProxyPin قيد التشغيل ويخفيه في علبة النظام.';

  @override
  String get trayClosePromptContent => 'إغلاق النافذة سيبقي ProxyPin قيد التشغيل في علبة النظام. هل تريد تصغيره الآن؟';

  @override
  String get trayCloseExitAnyway => 'الخروج على أي حال';

  @override
  String get trayCloseMinimizeToTray => 'تصغير إلى علبة النظام';

  @override
  String get copied => 'تم النسخ إلى الحافظة';

  @override
  String get execute => 'تنفيذ';

  @override
  String get cancel => 'إلغاء';

  @override
  String get close => 'إغلاق';

  @override
  String get save => 'حفظ';

  @override
  String get confirm => 'تأكيد';

  @override
  String get confirmTitle => 'تأكيد العملية';

  @override
  String get confirmContent => 'هل أنت متأكد من هذه العملية؟';

  @override
  String get addSuccess => 'تمت الإضافة بنجاح';

  @override
  String get saveSuccess => 'تم الحفظ بنجاح';

  @override
  String get operationSuccess => 'تمت العملية بنجاح';

  @override
  String get import => 'استيراد';

  @override
  String get importSuccess => 'تم الاستيراد بنجاح';

  @override
  String get importFailed => 'فشل الاستيراد';

  @override
  String get export => 'تصدير';

  @override
  String get exportSuccess => 'تم التصدير بنجاح';

  @override
  String get exportFailed => 'فشل التصدير';

  @override
  String get deleteSuccess => 'تم الحذف بنجاح';

  @override
  String get send => 'إرسال';

  @override
  String get fail => 'فشل';

  @override
  String get success => 'نجاح';

  @override
  String get emptyData => 'لا توجد بيانات';

  @override
  String get requestSuccess => 'تم الطلب بنجاح';

  @override
  String get add => 'إضافة';

  @override
  String get all => 'الكل';

  @override
  String get modify => 'تعديل';

  @override
  String get responseType => 'نوع الاستجابة';

  @override
  String get request => 'طلب';

  @override
  String get response => 'استجابة';

  @override
  String get statusCode => 'رمز الحالة';

  @override
  String get duration => 'المدة';

  @override
  String get done => 'تم';

  @override
  String get type => 'النوع';

  @override
  String get enable => 'تفعيل';

  @override
  String get example => 'مثال: ';

  @override
  String get responseHeader => 'رؤوس الاستجابة';

  @override
  String get requestHeader => 'رؤوس الطلب';

  @override
  String get requestLine => 'سطر الطلب';

  @override
  String get requestMethod => 'طريقة الطلب';

  @override
  String get param => 'معامل';

  @override
  String get replaceBodyWith => 'استبدال الجسم بـ:';

  @override
  String get redirectTo => 'إعادة التوجيه إلى:';

  @override
  String get redirect => 'إعادة توجيه';

  @override
  String get cannotBeEmpty => 'لا يمكن أن يكون فارغًا';

  @override
  String get requestRewriteList => 'قائمة إعادة كتابة الطلب';

  @override
  String get requestRewriteRule => 'قاعدة إعادة كتابة الطلب';

  @override
  String get requestRewriteEnable => 'تفعيل إعادة كتابة الطلب';

  @override
  String get action => 'إجراء';

  @override
  String get multiple => 'متعدد';

  @override
  String get edit => 'تحرير';

  @override
  String get moveUp => 'نقل للأعلى';

  @override
  String get moveDown => 'نقل لأسفل';

  @override
  String get dragSort => 'اسحب للفرز';

  @override
  String get disabled => 'معطل';

  @override
  String requestRewriteDeleteConfirm(Object size) {
    return 'حذف $size من القواعد؟';
  }

  @override
  String get useGuide => 'استخدام الدليل';

  @override
  String get pleaseEnter => 'الرجاء الإدخال';

  @override
  String get click => 'انقر';

  @override
  String get loadRemoteScript => 'تحميل برنامج نصي عن بُعد';

  @override
  String get replace => 'استبدال';

  @override
  String get clickEdit => 'انقر للتعديل';

  @override
  String get refresh => 'تحديث';

  @override
  String get selectFile => 'اختر ملف';

  @override
  String get match => 'مطابقة';

  @override
  String get value => 'قيمة';

  @override
  String get matchRule => 'قاعدة المطابقة';

  @override
  String get emptyMatchAll => 'فارغ يعني مطابقة الكل';

  @override
  String get newBuilt => 'جديد';

  @override
  String get reportServers => 'خوادم التقارير';

  @override
  String get addReportServer => 'إضافة خادم تقارير';

  @override
  String get editReportServer => 'تعديل خادم تقارير';

  @override
  String get splitReport => 'تقسيم التقرير';

  @override
  String get serverUrl => 'URL الخادم';

  @override
  String get compression => 'ضغط';

  @override
  String get compressionNone => 'بدون';

  @override
  String get newFolder => 'مجلد جديد';

  @override
  String get enableSelect => 'تمكين التحديد';

  @override
  String get disableSelect => 'تعطيل التحديد';

  @override
  String get deleteSelect => 'حذف التحديد';

  @override
  String get testData => 'بيانات اختبار';

  @override
  String get noChangesDetected => 'لم يتم اكتشاف تغييرات';

  @override
  String get enterMatchData => 'أدخل البيانات للمطابقة';

  @override
  String get modifyRequestHeader => 'تعديل رأس الطلب';

  @override
  String get headerName => 'اسم رأس الطلب';

  @override
  String get headerValue => 'قيمة رأس الطلب';

  @override
  String get deleteHeaderConfirm => 'هل تريد حذف رأس الطلب؟';

  @override
  String get sequence => 'جميع الطلبات';

  @override
  String get domainList => 'قائمة النطاقات';

  @override
  String get domainWhitelist => 'القائمة البيضاء لنطاقات البروكسي';

  @override
  String get domainBlacklist => 'القائمة السوداء لنطاقات البروكسي';

  @override
  String get domainFilter => 'قائمة نطاقات البروكسي';

  @override
  String get appWhitelist => 'القائمة البيضاء للتطبيقات';

  @override
  String get appWhitelistDescribe =>
      'يتم توجيه البروكسي فقط للتطبيقات الموجودة في القائمة البيضاء. عند تفعيل القائمة البيضاء تصبح القائمة السوداء غير فعالة';

  @override
  String get appBlacklist => 'القائمة السوداء للتطبيقات';

  @override
  String get scanCode => 'امسح الرمز للاتصال';

  @override
  String get addBlacklist => 'إضافة إلى القائمة السوداء للبروكسي';

  @override
  String get addWhitelist => 'إضافة إلى القائمة البيضاء للبروكسي';

  @override
  String get deleteWhitelist => 'حذف القائمة البيضاء للبروكسي';

  @override
  String domainListSubtitle(Object count, Object time) {
    return 'آخر طلب: $time، العدد: $count';
  }

  @override
  String get selectAction => 'اختر إجراء';

  @override
  String get select => 'اختر';

  @override
  String get copy => 'نسخ';

  @override
  String get copyHost => 'نسخ المضيف';

  @override
  String get copyUrl => 'نسخ URL';

  @override
  String get copyRawRequest => 'نسخ الطلب الخام';

  @override
  String get copyRequestResponse => 'نسخ الطلب والاستجابة';

  @override
  String get copyCurl => 'نسخ cURL';

  @override
  String get copyAsPythonRequests => 'نسخ كـ Python Requests';

  @override
  String get copyAsFetch => 'نسخ كـ fetch';

  @override
  String get delete => 'حذف';

  @override
  String get rename => 'إعادة تسمية';

  @override
  String get repeat => 'تكرار';

  @override
  String get repeatAllRequests => 'تكرار جميع الطلبات';

  @override
  String get repeatDomainRequests => 'تكرار طلبات النطاق';

  @override
  String get customRepeat => 'تكرار مخصص';

  @override
  String get repeatCount => 'التكرارات';

  @override
  String get repeatInterval => 'الفاصل (ms)';

  @override
  String get repeatDelay => 'التأخير (ms)';

  @override
  String get scheduleTime => 'وقت الجدولة';

  @override
  String get fixed => 'ثابت';

  @override
  String get random => 'عشوائي';

  @override
  String get keepCustomSettings => 'الاحتفاظ بالإعدادات المخصصة';

  @override
  String get editRequest => 'تحرير وإرسال الطلب';

  @override
  String get reSendRequest => 'تمت إعادة إرسال الطلب';

  @override
  String get viewExport => 'عرض التصدير';

  @override
  String get exportDomainHar => 'تصدير HAR لهذا النطاق';

  @override
  String get timeDesc => 'تنازليًا حسب الوقت';

  @override
  String get timeAsc => 'تصاعديًا حسب الوقت';

  @override
  String get search => 'بحث';

  @override
  String get clearSearch => 'مسح البحث';

  @override
  String get requestType => 'نوع الطلب';

  @override
  String get keyword => 'كلمة مفتاحية';

  @override
  String get keywordSearchScope => 'نطاق بحث الكلمة المفتاحية: ';

  @override
  String get favorite => 'مفضل';

  @override
  String get deleteFavorite => 'حذف المفضل';

  @override
  String get emptyFavorite => 'تفريغ المفضلات';

  @override
  String get deleteFavoriteSuccess => 'تم حذف المفضل';

  @override
  String get historyRecord => 'السجل';

  @override
  String get historyCacheTime => 'مدة التخزين المؤقت';

  @override
  String get historyManualSave => 'حفظ يدوي';

  @override
  String historyDay(Object day) {
    return '$day أيام';
  }

  @override
  String get historyForever => 'إلى الأبد';

  @override
  String historyRecordTitle(Object length, Object name) {
    return '$name سجلات $length';
  }

  @override
  String get historyEmptyName => 'لا يمكن أن يكون الاسم فارغًا';

  @override
  String historySubtitle(Object requestLength, Object size) {
    return 'سجلات $requestLength ملف $size';
  }

  @override
  String get historyUnSave => 'السجل الحالي غير محفوظ';

  @override
  String get historyDeleteConfirm => 'هل تريد حذف هذا السجل؟';

  @override
  String get requestEdit => 'تحرير الطلب';

  @override
  String get encode => 'ترميز';

  @override
  String get requestBody => 'جسم الطلب';

  @override
  String get responseBody => 'جسم الاستجابة';

  @override
  String get requestRewrite => 'إعادة كتابة الطلب';

  @override
  String get newWindow => 'نافذة جديدة';

  @override
  String get httpRequest => 'طلب HTTP';

  @override
  String get enabledHttps => 'تفعيل وكيل HTTPS';

  @override
  String get installRootCa => 'تثبيت الشهادة';

  @override
  String get installCaLocal => 'تثبيت الشهادة على الجهاز المحلي';

  @override
  String get downloadRootCa => 'تنزيل الشهادة';

  @override
  String get downloadRootCaNote =>
      'ملاحظة: إذا لم يكن المتصفح الافتراضي Safari، اضغط هذا السطر لنسخ الرابط ولصقه في Safari';

  @override
  String get generateCA => 'إنشاء شهادة جذر جديدة';

  @override
  String get generateCADescribe =>
      'هل أنت متأكد من رغبتك في إنشاء شهادة جذر جديدة؟ إذا أكدت،\nستحتاج إلى إعادة تثبيت الشهادة الجديدة ومنحها الثقة';

  @override
  String get resetDefaultCA => 'إعادة تعيين شهادة الجذر الافتراضية';

  @override
  String get resetDefaultCADescribe =>
      'هل تريد بالتأكيد إعادة التعيين إلى شهادة الجذر الافتراضية؟\nشهادة الجذر الافتراضية لـ ProxyPin هي نفسها لجميع المستخدمين.';

  @override
  String get exportCaP12 => 'تصدير شهادة الجذر (.p12)';

  @override
  String get importCaP12 => 'استيراد شهادة الجذر (.p12)';

  @override
  String get trustCa => 'وثق الشهادة';

  @override
  String get profileDownload => 'تنزيل الملف التعريفي';

  @override
  String get exportCA => 'تصدير شهادة الجذر';

  @override
  String get exportPrivateKey => 'تصدير المفتاح الخاص';

  @override
  String get install => 'تثبيت';

  @override
  String get installCaDescribe => 'إعدادات CA > تنزيل الملف التعريفي > تثبيت';

  @override
  String get trustCaDescribe => 'إعداد ثقة CA > عام > حول > إعدادات ثقة الشهادة';

  @override
  String get androidRoot => 'شهادة النظام (جهاز ROOT)';

  @override
  String get androidRootMagisk =>
      'وحدة Magisk:\nيمكن لأجهزة Android ذات صلاحيات ROOT استخدام وحدة ProxyPinCA لشهادة النظام في Magisk. بعد التثبيت وإعادة تشغيل الهاتف تحقق من شهادات النظام لوجود شهادة ProxyPinCA؛ إن وُجدت فتم التثبيت بنجاح.';

  @override
  String androidRootRename(Object name) {
    return 'إذا لم تعمل الوحدة، يمكنك تثبيت شهادة الجذر النظامية بحسب الدليل على الإنترنت وتسميتها $name';
  }

  @override
  String get androidRootCADownload => 'تنزيل شهادة النظام (.0)';

  @override
  String get androidUserCA => 'شهادة المستخدم';

  @override
  String get androidUserCATips => 'ملاحظة: في Android 7+ العديد من التطبيقات لا تثق بشهادات المستخدم';

  @override
  String get androidUserCAInstall => 'افتح الإعدادات -> الأمان -> التشفير والشهادات -> تثبيت شهادة -> شهادة CA';

  @override
  String get androidUserXposed => 'ينصح باستخدام وحدة Xposed لالتقاط الحزم (دون الحاجة إلى ROOT)، انقر لعرض الويكي';

  @override
  String get configWifiProxy => 'تكوين وكيل Wi-Fi على الهاتف';

  @override
  String get caInstallGuide => 'دليل تثبيت الشهادة';

  @override
  String get caAndroidBrowser => 'افتح متصفح Google على أجهزة Android:';

  @override
  String get caIosBrowser => 'افتح Safari على أجهزة iOS:';

  @override
  String get localIP => 'IP المحلي';

  @override
  String get mobileScan => 'تكوين وكيل Wi-Fi أو المسح بتطبيق الهاتف';

  @override
  String get decode => 'فك الترميز';

  @override
  String get encodeInput => 'أدخل المحتوى المراد تحويله';

  @override
  String get encodeResult => 'نتيجة التحويل';

  @override
  String get encodeFail => 'فشل الترميز';

  @override
  String get decodeFail => 'فشل فك الترميز';

  @override
  String get shareUrl => 'مشاركة رابط الطلب';

  @override
  String get shareCurl => 'مشاركة طلب cURL';

  @override
  String get requestResponse => 'الطلب والاستجابة';

  @override
  String get captureDetail => 'تفاصيل الالتقاط';

  @override
  String get proxyPinSoftware => 'برنامج ProxyPin مفتوح المصدر لالتقاط الحركة على جميع المنصات';

  @override
  String get prompt => 'تنبيه';

  @override
  String get curlSchemeRequest => 'إذا تم التعرف على صيغة curl، هل تريد تحويلها إلى طلب HTTP؟';

  @override
  String get appExitTips => 'اضغط مرة أخرى للخروج من التطبيق';

  @override
  String get remoteConnectDisconnect => 'فشل فحص الاتصال البعيد، تم قطع الاتصال';

  @override
  String get connect => 'اتصل';

  @override
  String get reconnect => 'إعادة الاتصال';

  @override
  String remoteConnected(Object os) {
    return 'تم الاتصال بـ $os، سيتم تمرير الحركة إلى $os';
  }

  @override
  String get remoteConnectForward => 'اتصال بعيد، إعادة توجيه الطلبات إلى أجهزة طرفية أخرى';

  @override
  String get connectSuccess => 'تم الاتصال بنجاح';

  @override
  String get connectedRemote => 'متصل عن بُعد';

  @override
  String get connected => 'متصل';

  @override
  String get notConnected => 'غير متصل';

  @override
  String get disconnect => 'قطع الاتصال';

  @override
  String get ipLayerProxy => 'وكيل طبقة IP';

  @override
  String get ipLayerProxyDesc => 'يمكن لوكيل طبقة IP التقاط طلبات تطبيق Flutter';

  @override
  String get inputAddress => 'أدخل العنوان';

  @override
  String get syncConfig => 'مزامنة الإعدادات';

  @override
  String get pullConfigFail => 'فشل جلب التكوين، يرجى التحقق من اتصال الشبكة';

  @override
  String get sync => 'مزامنة';

  @override
  String get invalidQRCode => 'رمز QR غير معترف به';

  @override
  String get remoteConnectFail =>
      'فشل الاتصال. تحقق من السماح على نفس الـ LAN وجدار الحماية. على iOS يلزم تمكين أذونات الشبكة المحلية';

  @override
  String get remoteConnectSuccessTips => 'يجب تمكين التقاط الحزم على هاتفك لالتقاط الطلبات';

  @override
  String get windowMode => 'وضع النافذة';

  @override
  String get windowModeSubTitle => 'عند تمكين التقاط الحزم والدخول إلى الخلفية، عرض نافذة مصغرة';

  @override
  String get pipIcon => 'أيقونة اختصار النافذة';

  @override
  String get pipIconDescribe => 'عرض أيقونة للوصول السريع إلى النافذة المصغرة';

  @override
  String get bottomNavigation => 'شريط التنقل السفلي';

  @override
  String get bottomNavigationSubtitle => 'يُعرض شريط التنقل السفلي، سيسري التغيير بعد إعادة التشغيل';

  @override
  String get memoryCleanup => 'تنظيف الذاكرة';

  @override
  String get memoryCleanupSubtitle =>
      'تنظيف الطلبات تلقائياً عند الوصول إلى حد الذاكرة والاحتفاظ بأحدث 32 طلبًا بعد التنظيف';

  @override
  String get clearConfirm => 'تأكيد قبل مسح السجلات الملتقطة';

  @override
  String get clearConfirmSubtitle => 'عرض مربع تأكيد قبل مسح السجلات الملتقطة';

  @override
  String get unlimited => 'غير محدود';

  @override
  String get custom => 'مخصص';

  @override
  String get externalProxyAuth => 'مصادقة الوكيل (اختياري)';

  @override
  String get externalProxyServer => 'خادم الوكيل';

  @override
  String get externalProxyConnectFailure => 'فشل اتصال الوكيل الخارجي';

  @override
  String get externalProxyFailureConfirm =>
      'ستفشل جميع طلبات HTTP بسبب مشكلات اتصال الشبكة. هل تريد متابعة إعداد الوكلاء الخارجيين؟';

  @override
  String get mobileDisplayPacketCapture => 'عرض التقاط الحزم على الهاتف:';

  @override
  String proxyPortRepeat(Object port) {
    return 'فشل التشغيل، يرجى التحقق من أن المنفذ $port محجوز.';
  }

  @override
  String get reset => 'إعادة تعيين';

  @override
  String get proxyIgnoreDomain => 'الوكيل يتجاهل النطاقات';

  @override
  String get domainWhitelistDescribe =>
      'يُجرى البروكسي فقط على أسماء النطاق الموجودة في القائمة البيضاء. إذا كانت القائمة البيضاء مفعلة، ستصبح القائمة السوداء غير فعالة';

  @override
  String get domainBlacklistDescribe => 'أسماء النطاق في القائمة السوداء لن يتم توجيهها عبر الوكيل';

  @override
  String get domain => 'المضيف';

  @override
  String get enableScript => 'تمكين البرنامج النصي';

  @override
  String get scriptUseDescribe => 'استخدم JavaScript لتعديل الطلبات والاستجابات';

  @override
  String get scriptEdit => 'تعديل البرنامج النصي';

  @override
  String get scrollEnd => 'التمرير إلى النهاية';

  @override
  String get logger => 'سجل';

  @override
  String get material3 => 'Material 3 هو أحدث إصدار من نظام تصميم Google مفتوح المصدر';

  @override
  String get iosVpnBackgroundAudio =>
      'بعد تفعيل التقاط الحزم والخروج إلى الخلفية، وللحفاظ على تشغيل خيط الواجهة الرئيسي للتواصل الشبكي، سيتم تفعيل تشغيل صوت صامت ليبقي الخيط الرئيسي قيد التشغيل. وإلا فسوف يعمل التطبيق في الخلفية لمدة 30 ثانية فقط. هل توافق على تشغيل صوت في الخلفية بعد تفعيل التقاط الحزم؟';

  @override
  String get markRead => 'وضع كمقروء';

  @override
  String get autoRead => 'القراءة التلقائية';

  @override
  String get highlight => 'إبراز';

  @override
  String get blue => 'أزرق';

  @override
  String get green => 'أخضر';

  @override
  String get yellow => 'أصفر';

  @override
  String get red => 'أحمر';

  @override
  String get pink => 'وردي';

  @override
  String get gray => 'رمادي';

  @override
  String get underline => 'تحته خط';

  @override
  String get requestBlock => 'حظر الطلب';

  @override
  String get other => 'أخرى';

  @override
  String get certHashName => 'اسم تجزئة CA';

  @override
  String get regExp => 'RegExp';

  @override
  String get systemCertName => 'اسم شهادة النظام';

  @override
  String get qrCode => 'رمز QR';

  @override
  String get jsonViewer => 'عارض JSON';

  @override
  String get xmlViewer => 'عارض XML';

  @override
  String get textDiff => 'مقارنة نصية';

  @override
  String get textEditor => 'محرر نص';

  @override
  String get compare => 'مقارنة';

  @override
  String get diffOriginal => 'الأصلي';

  @override
  String get diffChanged => 'المعدل';

  @override
  String get diffIdentical => 'النصان متطابقان';

  @override
  String diffSummary(int added, int removed) {
    return '+$added −$removed';
  }

  @override
  String get text => 'نص';

  @override
  String get format => 'تنسيق';

  @override
  String get compact => 'مضغوط';

  @override
  String get wordWrap => 'التفاف الأسطر';

  @override
  String get scanQrCode => 'مسح رمز QR';

  @override
  String get generateQrCode => 'إنشاء';

  @override
  String get saveImage => 'حفظ الصورة';

  @override
  String get selectImage => 'اختيار صورة';

  @override
  String get inputContent => 'محتوى الإدخال';

  @override
  String get errorCorrectLevel => 'مستوى تصحيح الخطأ';

  @override
  String get output => 'الإخراج';

  @override
  String get timestamp => 'الطابع الزمني';

  @override
  String get convert => 'تحويل';

  @override
  String get time => 'التاريخ والوقت';

  @override
  String get nowTimestamp => 'الطابع الزمني الآن';

  @override
  String get hosts => 'المضيفون';

  @override
  String get toAddress => 'إلى العنوان';

  @override
  String get encrypt => 'تشفير';

  @override
  String get decrypt => 'فك التشفير';

  @override
  String get cipher => 'شيفرة';

  @override
  String get view => 'عرض';

  @override
  String get appUpdateCheckVersion => 'التحقق من التحديثات';

  @override
  String get appUpdateNotAvailableMsg => 'أنت تستخدم أحدث إصدار بالفعل';

  @override
  String get appUpdateDialogTitle => 'تحديث متاح';

  @override
  String get appUpdateUpdateMsg => 'يوجد إصدار جديد من ProxyPin. هل تريد التحديث الآن؟';

  @override
  String get appUpdateCurrentVersionLbl => 'الإصدار الحالي';

  @override
  String get appUpdateNewVersionLbl => 'الإصدار الجديد';

  @override
  String get appUpdateUpdateNowBtnTxt => 'تحديث الآن';

  @override
  String get appUpdateLaterBtnTxt => 'لاحقًا';

  @override
  String get appUpdateIgnoreBtnTxt => 'تجاهل';

  @override
  String get appUpdateInstallNow => 'تثبيت الآن';

  @override
  String get appUpdateRetry => 'إعادة المحاولة';

  @override
  String get appUpdateBackgroundDownload => 'التحميل في الخلفية';

  @override
  String get appUpdateOpenDownloadPage => 'فتح صفحة التنزيل';

  @override
  String get requestMap => 'خريطة الطلبات';

  @override
  String get requestMapDescribe => 'لا تطلب خدمات عن بُعد، استخدم التكوين المحلي أو سكربت للرد';

  @override
  String get automatic => 'تلقائي';

  @override
  String get manual => 'يدوي';

  @override
  String get certNotInstalled => 'الشهادة غير مثبتة';

  @override
  String get openNewWindow => 'فتح نافذة جديدة';

  @override
  String get sponsorDonate => 'ادعم / تبرع';

  @override
  String get sponsorSupport => 'ادعم استمرار التطوير';

  @override
  String get sponsorThanks =>
      'شكرًا لدعمك هذا المشروع مفتوح المصدر باختيار إحدى الطرق التالية للمساهمة في استمرارية تطويره.';

  @override
  String get sponsorAfdian => 'AFDIAN';

  @override
  String get privacyPolicy => 'سياسة الخصوصية';

  @override
  String get privacyContent =>
      'تعمل هذه الأداة مفتوحة المصدر لالتقاط الحزم بالكامل على جهازك. لا يوجد لها خادم خلفي ولا تجمع أو تخزن أو ترفع أي بيانات شخصية. تتم معالجة كل الحركة الملتقطة محليًا ولا تُعاد توجيهها إلا عندما تستخدم إعادة التوجيه عن بُعد صراحةً. تُستخدم الأذونات (مثل الشبكة والتخزين والكاميرا لرموز QR) فقط لتوفير الميزات. يمكنك مراجعة السلوك في الشيفرة المصدرية العامة.';

  @override
  String get requestCrypto => 'تشفير الطلب';

  @override
  String get cryptoDecoded => 'مفكك';

  @override
  String get cryptoDecodeToggle => 'فك التشفير';

  @override
  String get optional => 'اختياري';

  @override
  String get cryptoRuleField => 'اسم الحقل';

  @override
  String get cryptoIvPrefixLabel => 'بادئة IV';

  @override
  String get cryptoIvPrefixTooltip => 'استخدم أول N بايت من جسم الاستجابة كـ IV';

  @override
  String get local => 'محلي';

  @override
  String get remoteUrl => 'URL بعيد';

  @override
  String get preview => 'معاينة';

  @override
  String get environment => 'بيئة';

  @override
  String get environmentVariables => 'متغيرات البيئة';

  @override
  String get envGlobal => 'عام';

  @override
  String get envManage => 'إدارة البيئات…';

  @override
  String get envNone => 'لا توجد بيئة';

  @override
  String get envDeleteConfirm => 'حذف هذه البيئة؟';

  @override
  String get envEmptyHint => 'لا توجد متغيرات بعد. انقر + للإضافة.';

  @override
  String get envUsageHint => 'استخدم المتغيرات كـ %s في القواعد، أو اقرأ/اكتب عبر context.env في السكربتات.';

  @override
  String get envInsertBuiltIn => 'إدراج متغير مدمج';

  @override
  String get weakNetwork => 'تقييد الشبكة';

  @override
  String get weakNetworkPreset => 'إعداد مسبق';

  @override
  String get weakNetworkPresetOffline => 'غير متصل';

  @override
  String get weakNetworkPresetSlow => 'بطيء';

  @override
  String get weakNetworkPresetWeak => 'ضعيف';

  @override
  String get weakNetworkLatency => 'كمون';

  @override
  String get weakNetworkUpload => 'رفع';

  @override
  String get weakNetworkDownload => 'تنزيل';

  @override
  String get weakNetworkBandwidth => 'عرض النطاق';

  @override
  String get weakNetworkLossRate => 'فقدان الحزم';

  @override
  String get weakNetworkRules => 'قواعد URL';

  @override
  String get mcpService => 'خادم MCP';

  @override
  String get mcpServiceDescribe =>
      'يشغّل خادم HTTP محليًا للتواصل باستخدام بروتوكول Model Context (MCP) مع أدوات الذكاء الاصطناعي مثل Claude.';

  @override
  String get mcpEnable => 'تفعيل خادم MCP';

  @override
  String get mcpPort => 'المنفذ';

  @override
  String get mcpAdvanced => 'إعدادات متقدمة';

  @override
  String get mcpConfig => 'إعدادات MCP';

  @override
  String get mcpRedact => 'إخفاء البيانات الحساسة قبل إرسالها إلى الذكاء الاصطناعي';

  @override
  String get mcpRedactDescribe => 'إخفاء تلقائي للمعلومات الحساسة قبل إرسالها إلى أدوات الذكاء الاصطناعي.';

  @override
  String mcpHintRun(String client) {
    return 'شغّل هذا الأمر في الطرفية لإضافة ProxyPin MCP إلى $client.';
  }

  @override
  String get mcpAboutTitle => 'حول تكامل MCP';

  @override
  String get mcpAboutText =>
      'يتيح MCP (Model Context Protocol) لمساعدات الذكاء الاصطناعي مثل Claude التفاعل مع ProxyPin. يمكن للذكاء الاصطناعي قراءة حركة HTTP الملتقطة، وإنشاء قواعد تصحيح (Map Local، Map Remote، Breakpoints)، والمساعدة في تحليل مشكلات الشبكة.';

  @override
  String get mcpLearnMore => 'المزيد عن MCP';

  @override
  String get mcpSkills => 'المهارات';

  @override
  String get mcpSkillsTitle => 'مهارات MCP';

  @override
  String get mcpSkillsReadonly => 'أدوات قراءة حركة المرور فقط';

  @override
  String get mcpSkillsRules => 'أدوات القواعد وإعادة التشغيل والبيئة';

  @override
  String get mcpEndpoint => 'نقطة نهاية MCP';

  @override
  String get mcpPortInvalid => 'الرجاء إدخال منفذ صالح بين 1024 و65535';

  @override
  String get mcpAccessToken => 'رمز الوصول';

  @override
  String get mcpLanGuide =>
      'ضع هذا الهاتف والكمبيوتر على نفس شبكة Wi‑Fi، ثم شغّل أحد الأوامر أدناه في طرفية الكمبيوتر، أو الصق التهيئة في إعدادات MCP لعميل الذكاء الاصطناعي.';

  @override
  String get mcpLanTokenNote =>
      'يمنح الرمز وصولاً كاملاً إلى أدوات MCP. اضغط زر التحديث بجانب الرمز لإبطاله وإصدار رمز جديد.';

  @override
  String get mcpOtherClients => 'عملاء ذكاء اصطناعي آخرون';

  @override
  String get mcpOtherClientsHint =>
      'تهيئة HTTP قابلة للبث عالمية لـ Cursor, Cline, Gemini CLI, Cherry Studio, VS Code Copilot وغيرها من عملاء MCP. الصق URL وBearer token، أو JSON الكامل، في إعدادات MCP للعميل.';

  @override
  String get mcpOneClick => 'إعداد بنقرة واحدة على جهاز الكمبيوتر';

  @override
  String get mcpOneClickHint =>
      'انسخ الأمر المطابق وشغّله على الكمبيوتر: الطرفية لـ macOS/Linux، PowerShell لـ Windows. يكتشف عملاء الذكاء الاصطناعي المثبتين تلقائياً (Claude Code، Codex، Cursor، Gemini CLI) ويقوم بتكوينهم عبر Wi‑Fi.';

  @override
  String get mcpRegenerateToken => 'إعادة تعيين الرمز';

  @override
  String get mcpStatusRunning => 'قيد التشغيل';

  @override
  String get mcpStatusStopped => 'متوقف';

  @override
  String get mcpClientLabel => 'عميل الذكاء الاصطناعي';

  @override
  String get mcpTransportLabel => 'نوع النقل';

  @override
  String get mcpCommandLabel => 'أمر الاتصال';

  @override
  String get mcpClientsIntl => 'دولي';

  @override
  String get mcpClientsDomestic => 'صيني';

  @override
  String get mcpTransportStdio => 'stdio';

  @override
  String get mcpTransportHttp => 'HTTP';

  @override
  String get mcpHintTerminal => 'انسخها وشغّلها في الطرفية.';

  @override
  String get mcpHintJson => 'الصقها في إعدادات MCP لعميلك.';

  @override
  String get mcpHintCopilot => 'الصقها في settings.json لـ VS Code → mcp.servers.';

  @override
  String get mcpHintLingma => 'Tongyi Lingma IDE → Profile → Settings → MCP Service → أضف يدوياً (HTTP/URL type).';

  @override
  String get mcpHintCherry => 'Cherry Studio → الإعدادات → MCP Servers → إضافة.';

  @override
  String get mcpHintDoubao => 'MarsCode IDE → الإعدادات → MCP → إضافة (نوع HTTP/URL).';

  @override
  String get mcpSetup => 'تكوين تلقائي';

  @override
  String get mcpStartChat => 'بدء المحادثة';

  @override
  String get mcpOpenTerminal => 'تشغيل في الطرفية';

  @override
  String get mcpSetupDone => 'تم التكوين. أعد تشغيل عميل الذكاء الاصطناعي لتطبيق التغييرات.';

  @override
  String get mcpSetupFail => 'فشل الإعداد: ';

  @override
  String mcpCliMissing(Object cli) {
    return 'لم يتم العثور على CLI $cli في PATH. استخدم \"تشغيل في الطرفية\" بدلاً من ذلك.';
  }

  @override
  String get mcpUnsupported => 'هذا العميل لا يدعم الإعداد التلقائي، قم بتكوينه يدوياً.';

  @override
  String get mcpCopy => 'نسخ';

  @override
  String get mcpCopied => 'تم النسخ';

  @override
  String get mcpStartFailed => 'فشل تشغيل خدمة MCP';

  @override
  String get mcpPrivacyHint =>
      'يستمع فقط على 127.0.0.1 (هذا الجهاز). تخرج البيانات من التطبيق فقط عندما يطلبها عميل الذكاء الاصطناعي صراحةً عبر أداة.';
}
