package com.revdex.aantik;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.mode.adel.R;

import java.util.List;

/**
 * Adapter for the list of installed applications.
 * Each row is res.layout.cjump (icon + name + status + chevron).
 */
public class AppAdapter extends RecyclerView.Adapter<AppAdapter.AppViewHolder> {

    public interface OnAppClickListener {
        void onAppClick(AppItem app);
    }

    private final Context context;
    private final List<AppItem> appList;
    private final OnAppClickListener listener;

    public AppAdapter(Context context, List<AppItem> appList, OnAppClickListener listener) {
        this.context = context;
        this.appList = appList;
        this.listener = listener;
    }

    @Override
    public AppViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.cjump, parent, false);
        return new AppViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AppViewHolder holder, int position) {
        final AppItem app = this.appList.get(position);
        holder.appIcon.setImageDrawable(app.getIcon());
        holder.appName.setText(app.getAppName());
        holder.appStatus.setText(app.isInstalled()
                ? "\u0645\u062b\u0628\u0651\u062a \u062f\u0627\u062e\u0644 \u0627\u0644\u0628\u064a\u0626\u0629 \u2014 \u0627\u0636\u063a\u0637 \u0644\u0644\u0628\u062f\u0621"
                : "\u0627\u0636\u063a\u0637 \u0644\u0644\u062a\u062b\u0628\u064a\u062a \u0648\u0627\u0644\u0627\u0633\u062a\u062e\u0631\u0627\u062c");
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AppAdapter.this.listener != null) {
                    AppAdapter.this.listener.onAppClick(app);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.appList.size();
    }

    public static class AppViewHolder extends RecyclerView.ViewHolder {
        final ImageView appIcon;
        final TextView appName;
        final TextView appStatus;

        AppViewHolder(View itemView) {
            super(itemView);
            this.appIcon = itemView.findViewById(R.id.appIcon);
            this.appName = itemView.findViewById(R.id.appName);
            this.appStatus = itemView.findViewById(R.id.appStatus);
        }
    }

    public static class AppItem {
        private String appName;
        private String packageName;
        private Drawable icon;
        private boolean installed;
        private String sourceApkPath;
        private String[] splitApkPaths;

        public AppItem(String appName, String packageName, Drawable icon, boolean installed,
                       String sourceApkPath, String[] splitApkPaths) {
            this.appName = appName;
            this.packageName = packageName;
            this.icon = icon;
            this.installed = installed;
            this.sourceApkPath = sourceApkPath;
            this.splitApkPaths = splitApkPaths == null ? new String[0] : (String[]) splitApkPaths.clone();
        }

        public String getAppName() { return this.appName; }
        public void setAppName(String appName) { this.appName = appName; }
        public String getPackageName() { return this.packageName; }
        public void setPackageName(String packageName) { this.packageName = packageName; }
        public Drawable getIcon() { return this.icon; }
        public void setIcon(Drawable icon) { this.icon = icon; }
        public boolean isInstalled() { return this.installed; }
        public void setInstalled(boolean installed) { this.installed = installed; }
        public String getSourceApkPath() { return this.sourceApkPath; }
        public void setSourceApkPath(String sourceApkPath) { this.sourceApkPath = sourceApkPath; }
        public String[] getSplitApkPaths() { return this.splitApkPaths; }
        public void setSplitApkPaths(String[] splitApkPaths) { this.splitApkPaths = splitApkPaths; }
    }
}
