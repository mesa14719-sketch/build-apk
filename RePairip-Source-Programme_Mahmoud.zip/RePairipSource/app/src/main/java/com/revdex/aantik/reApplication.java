package com.revdex.aantik;

import android.app.Application;
import android.content.Context;
import com.antik.utils.EmbeddedResources;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

/* loaded from: classes3.dex */
public class reApplication extends Application {
    public static reApplication gApp;

    public static reApplication get() {
        return gApp;
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(final Context base) {
        super.attachBaseContext(base);
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() { // from class: com.revdex.aantik.reApplication.1
                @Override // top.niunaijun.blackbox.app.configuration.ClientConfiguration
                public String getHostPackageName() {
                    return base.getPackageName();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        gApp = this;
        EmbeddedResources.init(this);
        try {
            BlackBoxCore.get().doCreate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
