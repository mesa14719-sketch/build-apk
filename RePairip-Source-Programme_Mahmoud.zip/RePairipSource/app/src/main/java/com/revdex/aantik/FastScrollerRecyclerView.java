package com.revdex.aantik;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes3.dex */
public class FastScrollerRecyclerView extends RecyclerView {
    private final Runnable hideScrollerRunnable;
    private boolean isDefaultScrollBarEnabled;
    private boolean isDragging;
    private boolean isScrollerCurrentlyVisible;
    private final boolean isScrollerEnabled;
    private boolean isTrackVisible;
    private long lastInteractionTime;
    private int lastScrollPosition;
    private final Paint scrollerPaint;
    private final int thumbColor;
    private final float thumbHeight;
    private final RectF thumbRect;
    private final float thumbWidth;
    private float touchOffset;

    public FastScrollerRecyclerView(Context context) {
        this(context, null);
    }

    public FastScrollerRecyclerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FastScrollerRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.isScrollerEnabled = true;
        this.hideScrollerRunnable = new Runnable() { // from class: com.revdex.aantik.FastScrollerRecyclerView.1
            @Override // java.lang.Runnable
            public void run() {
                FastScrollerRecyclerView.this.invalidate();
            }
        };
        this.isDragging = false;
        this.isScrollerCurrentlyVisible = false;
        this.lastInteractionTime = 0L;
        this.isDefaultScrollBarEnabled = true;
        this.isTrackVisible = true;
        this.thumbRect = new RectF();
        this.scrollerPaint = new Paint(1);
        float density = context.getResources().getDisplayMetrics().density;
        this.thumbColor = -580491674;
        this.thumbWidth = 8.0f * density;
        this.thumbHeight = 48.0f * density;
        setWillNotDraw(false);
        addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.revdex.aantik.FastScrollerRecyclerView.2
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (!FastScrollerRecyclerView.this.isDragging) {
                    FastScrollerRecyclerView.this.lastInteractionTime = SystemClock.uptimeMillis();
                    FastScrollerRecyclerView fastScrollerRecyclerView = FastScrollerRecyclerView.this;
                    fastScrollerRecyclerView.removeCallbacks(fastScrollerRecyclerView.hideScrollerRunnable);
                    FastScrollerRecyclerView fastScrollerRecyclerView2 = FastScrollerRecyclerView.this;
                    fastScrollerRecyclerView2.postDelayed(fastScrollerRecyclerView2.hideScrollerRunnable, 1500L);
                }
                FastScrollerRecyclerView.this.invalidate();
            }
        });
        super.setLayoutManager(new LinearLayoutManager(context));
        RecyclerView.ItemAnimator animator = getItemAnimator();
        if (animator != null) {
            animator.setAddDuration(100L);
            animator.setRemoveDuration(100L);
            animator.setMoveDuration(200L);
            animator.setChangeDuration(100L);
        }
        this.lastScrollPosition = -1;
    }

    public void setTrackVisible(boolean visible) {
        this.isTrackVisible = visible;
        invalidate();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (getAdapter() == null) {
            return;
        }
        int itemCount = getAdapter().getItemCount();
        int childCount = getChildCount();
        if (childCount > 0 && itemCount - childCount > 0) {
            if (itemCount / childCount > 4) {
                int range = computeVerticalScrollRange();
                int extent = computeVerticalScrollExtent();
                int offset = computeVerticalScrollOffset();
                int scrollableRange = range - extent;
                if (scrollableRange <= 0) {
                    this.isScrollerCurrentlyVisible = false;
                    return;
                }
                float alphaMultiplier = 1.0f;
                float slideOffset = 0.0f;
                if (!this.isDragging && 0 == 0) {
                    long timeSinceInteraction = SystemClock.uptimeMillis() - this.lastInteractionTime;
                    if (timeSinceInteraction >= 1500) {
                        float fadeProgress = Math.min(1.0f, (timeSinceInteraction - 1500) / 300.0f);
                        alphaMultiplier = 1.0f - fadeProgress;
                        slideOffset = this.thumbWidth * fadeProgress;
                    }
                }
                if (alphaMultiplier <= 0.0f) {
                    this.isScrollerCurrentlyVisible = false;
                    return;
                }
                this.isScrollerCurrentlyVisible = true;
                if (this.isDefaultScrollBarEnabled) {
                    this.isDefaultScrollBarEnabled = false;
                    setVerticalScrollBarEnabled(false);
                }
                int width = getWidth();
                int height = getHeight();
                canvas.save();
                canvas.translate(slideOffset, 0.0f);
                if (this.isTrackVisible) {
                    int trackAlpha = (int) (Color.alpha(285212672) * alphaMultiplier);
                    this.scrollerPaint.setColor((trackAlpha << 24) | (285212672 & ViewCompat.MEASURED_SIZE_MASK));
                    float trackLeft = width - this.thumbWidth;
                    canvas.drawRect(trackLeft, 0.0f, width, height, this.scrollerPaint);
                }
                int activeColor = this.isDragging ? -14776091 : this.thumbColor;
                int thumbAlpha = (int) (Color.alpha(activeColor) * alphaMultiplier);
                this.scrollerPaint.setColor((thumbAlpha << 24) | (activeColor & ViewCompat.MEASURED_SIZE_MASK));
                float f = this.thumbHeight;
                float thumbTop = (offset / scrollableRange) * (height - f);
                float thumbBottom = thumbTop + f;
                float thumbLeft = width - this.thumbWidth;
                float density = getContext().getResources().getDisplayMetrics().density;
                float touchWidth = density * 48.0f;
                float touchPaddingVertical = density * 12.0f;
                this.thumbRect.set(width - touchWidth, thumbTop - touchPaddingVertical, width, thumbBottom + touchPaddingVertical);
                canvas.drawRect(thumbLeft, thumbTop, width, thumbBottom, this.scrollerPaint);
                canvas.restore();
                if (alphaMultiplier < 1.0f) {
                    postInvalidateOnAnimation();
                    return;
                }
                return;
            }
        }
        if (!this.isDefaultScrollBarEnabled) {
            this.isDefaultScrollBarEnabled = true;
            setVerticalScrollBarEnabled(true);
        }
        this.isScrollerCurrentlyVisible = false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (this.isScrollerCurrentlyVisible && ev.getAction() == 0 && this.thumbRect.contains(ev.getX(), ev.getY())) {
            this.isDragging = true;
            removeCallbacks(this.hideScrollerRunnable);
            this.touchOffset = this.thumbRect.top - ev.getY();
            return true;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.View
    public boolean onTouchEvent(MotionEvent ev) {
        if (this.isDragging) {
            switch (ev.getAction()) {
                case 0:
                    this.lastScrollPosition = -1;
                    invalidate();
                    break;
                case 1:
                case 3:
                    this.isDragging = false;
                    this.lastInteractionTime = SystemClock.uptimeMillis();
                    removeCallbacks(this.hideScrollerRunnable);
                    postDelayed(this.hideScrollerRunnable, 1500L);
                    invalidate();
                    break;
                case 2:
                    float relativeY = (ev.getY() + this.touchOffset) / (getHeight() - this.thumbHeight);
                    float relativeY2 = Math.max(0.0f, Math.min(1.0f, relativeY));
                    int position = 0;
                    if (getAdapter() != null) {
                        position = (int) ((getAdapter().getItemCount() - 1) * relativeY2);
                    }
                    if (this.lastScrollPosition != position) {
                        this.lastScrollPosition = position;
                        if (getLayoutManager() != null) {
                            ((LinearLayoutManager) getLayoutManager()).scrollToPositionWithOffset(position, 0);
                            break;
                        }
                    }
                    break;
            }
            return true;
        }
        return super.onTouchEvent(ev);
    }
}
