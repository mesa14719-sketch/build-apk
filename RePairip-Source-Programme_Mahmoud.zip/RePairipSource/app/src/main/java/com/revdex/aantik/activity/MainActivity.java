package com.revdex.aantik.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.antik.PairipPatchPipeline;
import com.mode.adel.R;
import com.revdex.aantik.AppAdapter;
import com.revdex.aantik.FastScrollerRecyclerView;
import com.revdex.aantik.activity.MainActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

/* loaded from: classes3.dex */
public class MainActivity extends AppCompatActivity {
    private static final int DUMP_STATUS_INTERVAL_MS = 350;
    private static final long DUMP_TIMEOUT_MS = 120000;
    private static final int REQUEST_STORAGE = 100;
    private String activeDumpPackage;
    private AppAdapter adapter;
    private FastScrollerRecyclerView appGrid;
    private List<AppAdapter.AppItem> appList;
    private AlertDialog dumpDialog;
    private TextView dumpMessageView;
    private ProgressBar dumpProgressBar;
    private long dumpStartTimeMs;
    private Runnable dumpStatusPoller;
    private boolean dumpStatusReadInFlight;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService dumpExecutor = Executors.newSingleThreadExecutor();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        try {
            setupSideMenu();
        } catch (Throwable ignored) {
            // never let the side menu break app start-up
        }
        checkPermissions();
        FastScrollerRecyclerView fastScrollerRecyclerView = (FastScrollerRecyclerView) findViewById(R.id.appGrid);
        this.appGrid = fastScrollerRecyclerView;
        fastScrollerRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.appList = new ArrayList();
        AppAdapter appAdapter = new AppAdapter(this, this.appList, new AppAdapter.OnAppClickListener() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda4
            @Override // com.revdex.aantik.AppAdapter.OnAppClickListener
            public final void onAppClick(AppAdapter.AppItem appItem) {
                MainActivity.this.startDumpFlow(appItem);
            }
        });
        this.adapter = appAdapter;
        this.appGrid.setAdapter(appAdapter);
        loadUserApps();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startDumpFlow(final AppAdapter.AppItem app) {
        if (this.activeDumpPackage != null) {
            t(this, "Another process is already running.");
            return;
        }
        this.activeDumpPackage = app.getPackageName();
        this.dumpStartTimeMs = System.currentTimeMillis();
        showDumpDialog(app);
        updateDumpDialog(1, "Preparing dump... 1%");
        this.dumpExecutor.execute(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m114lambda$startDumpFlow$4$comrevdexaantikactivityMainActivity(app);
            }
        });
    }

    /* renamed from: lambda$startDumpFlow$4$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m114lambda$startDumpFlow$4$comrevdexaantikactivityMainActivity(final AppAdapter.AppItem app) {
        final String error;
        clearDumpFiles(app.getPackageName());
        if (!app.isInstalled()) {
            this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m110lambda$startDumpFlow$0$comrevdexaantikactivityMainActivity();
                }
            });
            InstallResult installResult = BlackBoxCore.get().installPackageAsUser(app.getPackageName(), 0);
            if (installResult == null || !installResult.success) {
                if (installResult != null && installResult.msg != null) {
                    error = installResult.msg;
                } else {
                    error = "Install failed.";
                }
                this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.this.m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity(error);
                    }
                });
                return;
            }
            app.setInstalled(true);
            this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m112lambda$startDumpFlow$2$comrevdexaantikactivityMainActivity();
                }
            });
        }
        this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m113lambda$startDumpFlow$3$comrevdexaantikactivityMainActivity(app);
            }
        });
    }

    /* renamed from: lambda$startDumpFlow$0$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m110lambda$startDumpFlow$0$comrevdexaantikactivityMainActivity() {
        updateDumpDialog(2, "Installing in VM... 2%");
    }

    /* renamed from: lambda$startDumpFlow$2$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m112lambda$startDumpFlow$2$comrevdexaantikactivityMainActivity() {
        this.adapter.notifyDataSetChanged();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: launchDump, reason: merged with bridge method [inline-methods] */
    public void m113lambda$startDumpFlow$3$comrevdexaantikactivityMainActivity(AppAdapter.AppItem app) {
        if (!app.getPackageName().equals(this.activeDumpPackage)) {
            return;
        }
        updateDumpDialog(3, "Launching dumper... 3%");
        boolean launched = BlackBoxCore.get().launchApk(app.getPackageName(), 0);
        refreshList();
        if (!launched) {
            m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity("Unable to start the dumper.");
        } else {
            startDumpStatusPolling(app);
        }
    }

    /* renamed from: com.revdex.aantik.activity.MainActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Runnable {
        final /* synthetic */ AppAdapter.AppItem val$app;

        AnonymousClass1(AppAdapter.AppItem appItem) {
            this.val$app = appItem;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (MainActivity.this.dumpDialog != null && MainActivity.this.activeDumpPackage != null) {
                long elapsed = System.currentTimeMillis() - MainActivity.this.dumpStartTimeMs;
                if (elapsed > MainActivity.DUMP_TIMEOUT_MS) {
                    MainActivity.this.m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity("Dump timed out.");
                    return;
                }
                if (MainActivity.this.dumpStatusReadInFlight) {
                    MainActivity.this.uiHandler.postDelayed(this, 350L);
                    return;
                }
                MainActivity.this.dumpStatusReadInFlight = true;
                ExecutorService executorService = MainActivity.this.dumpExecutor;
                final AppAdapter.AppItem appItem = this.val$app;
                executorService.execute(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.AnonymousClass1.this.m116lambda$run$1$comrevdexaantikactivityMainActivity$1(appItem);
                    }
                });
            }
        }

        /* renamed from: lambda$run$1$com-revdex-aantik-activity-MainActivity$1, reason: not valid java name */
        /* synthetic */ void m116lambda$run$1$comrevdexaantikactivityMainActivity$1(final AppAdapter.AppItem app) {
            final DumpStatus status = MainActivity.this.readDumpStatus(app.getPackageName());
            MainActivity.this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.AnonymousClass1.this.m115lambda$run$0$comrevdexaantikactivityMainActivity$1(app, status);
                }
            });
        }

        /* renamed from: lambda$run$0$com-revdex-aantik-activity-MainActivity$1, reason: not valid java name */
        /* synthetic */ void m115lambda$run$0$comrevdexaantikactivityMainActivity$1(AppAdapter.AppItem app, DumpStatus status) {
            MainActivity.this.dumpStatusReadInFlight = false;
            if (MainActivity.this.dumpDialog == null || MainActivity.this.activeDumpPackage == null || !app.getPackageName().equals(MainActivity.this.activeDumpPackage)) {
                return;
            }
            if (status == null) {
                MainActivity.this.updateDumpDialog(3, "Launching dumper... 3%");
                MainActivity.this.uiHandler.postDelayed(MainActivity.this.dumpStatusPoller, 350L);
            } else {
                if (status.isFinished()) {
                    if ("done".equals(status.state)) {
                        MainActivity.this.beginPatchSession(app);
                        return;
                    } else {
                        MainActivity mainActivity = MainActivity.this;
                        mainActivity.m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity(mainActivity.resolveDumpMessage(status));
                        return;
                    }
                }
                int progress = Math.max(1, status.progress);
                MainActivity.this.updateDumpDialog(progress, "Dumping JSON... " + progress + "%");
                MainActivity.this.uiHandler.postDelayed(MainActivity.this.dumpStatusPoller, 350L);
            }
        }
    }

    private void startDumpStatusPolling(AppAdapter.AppItem app) {
        stopDumpStatusPolling();
        AnonymousClass1 anonymousClass1 = new AnonymousClass1(app);
        this.dumpStatusPoller = anonymousClass1;
        this.uiHandler.postDelayed(anonymousClass1, 350L);
    }

    private void stopDumpStatusPolling() {
        Runnable runnable = this.dumpStatusPoller;
        if (runnable != null) {
            this.uiHandler.removeCallbacks(runnable);
            this.dumpStatusPoller = null;
        }
        this.dumpStatusReadInFlight = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void beginPatchSession(final AppAdapter.AppItem app) {
        stopDumpStatusPolling();
        updateDumpDialog(1, "JSON dump complete. Preparing patch...");
        final File dumpFile = new File(getDumpOutputDir(app.getPackageName()), "pairip_dump.json");
        if (!dumpFile.isFile()) {
            m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity("Dump JSON not found: " + dumpFile.getAbsolutePath());
        } else {
            this.dumpExecutor.execute(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m106x7eccc319(app, dumpFile);
                }
            });
        }
    }

    /* renamed from: lambda$beginPatchSession$9$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m106x7eccc319(final AppAdapter.AppItem app, final File dumpFile) {
        try {
            final File outputFile = PairipPatchPipeline.patchInstalledPackage(this, app.getPackageName(), app.getSourceApkPath(), app.getSplitApkPaths(), dumpFile, getDumpOutputDir(app.getPackageName()), new PairipPatchPipeline.ProgressCallback() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda6
                @Override // com.antik.PairipPatchPipeline.ProgressCallback
                public final void onProgress(int i, String str) {
                    MainActivity.this.m103xd8ec4216(app, i, str);
                }
            });
            this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m104x658c6d17(dumpFile, outputFile);
                }
            });
        } catch (Exception e) {
            final String message = e.getMessage() != null ? e.getMessage() : "Patch failed.";
            this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.failDump(message);
                }
            });
        }
    }

    /* renamed from: lambda$beginPatchSession$6$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m103xd8ec4216(final AppAdapter.AppItem app, final int progress, final String message) {
        this.uiHandler.post(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m102x4c4c1715(app, progress, message);
            }
        });
    }

    /* renamed from: lambda$beginPatchSession$5$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m102x4c4c1715(AppAdapter.AppItem app, int progress, String message) {
        if (this.dumpDialog == null || this.activeDumpPackage == null || !app.getPackageName().equals(this.activeDumpPackage)) {
            return;
        }
        updateDumpDialog(progress, message);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: completePatchSession, reason: merged with bridge method [inline-methods] */
    public void m104x658c6d17(File dumpFile, File outputFile) {
        this.activeDumpPackage = null;
        this.dumpStartTimeMs = 0L;
        dismissDumpDialog();
        refreshList();
        showPatchSuccessDialog(dumpFile, outputFile);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: failDump, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public void m111lambda$startDumpFlow$1$comrevdexaantikactivityMainActivity(String message) {
        stopDumpStatusPolling();
        this.activeDumpPackage = null;
        this.dumpStartTimeMs = 0L;
        dismissDumpDialog();
        showErrorDialog(message);
    }

    private void showDumpDialog(AppAdapter.AppItem app) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(1);
        int padding = dp(20);
        container.setPadding(padding, padding, padding, padding);
        TextView textView = new TextView(this);
        this.dumpMessageView = textView;
        textView.setTextSize(15.0f);
        this.dumpMessageView.setTextColor(Color.parseColor("#757575"));
        this.dumpMessageView.setText("Preparing dump...");
        container.addView(this.dumpMessageView, new LinearLayout.LayoutParams(-1, -2));
        ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        this.dumpProgressBar = progressBar;
        progressBar.setMax(100);
        this.dumpProgressBar.setProgress(1);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, -2);
        progressParams.topMargin = dp(14);
        container.addView(this.dumpProgressBar, progressParams);
        AlertDialog create = new AlertDialog.Builder(this).setTitle(app.getAppName()).setView(container).setCancelable(false).create();
        this.dumpDialog = create;
        create.setCanceledOnTouchOutside(false);
        this.dumpDialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda5
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                MainActivity.this.m109lambda$showDumpDialog$10$comrevdexaantikactivityMainActivity(dialogInterface);
            }
        });
        this.dumpDialog.show();
    }

    /* renamed from: lambda$showDumpDialog$10$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m109lambda$showDumpDialog$10$comrevdexaantikactivityMainActivity(DialogInterface dialog) {
        stopDumpStatusPolling();
        this.activeDumpPackage = null;
        this.dumpStartTimeMs = 0L;
        this.dumpDialog = null;
        this.dumpProgressBar = null;
        this.dumpMessageView = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateDumpDialog(int progress, String message) {
        if (this.dumpDialog == null) {
            return;
        }
        ProgressBar progressBar = this.dumpProgressBar;
        if (progressBar != null) {
            progressBar.setProgress(Math.max(1, Math.min(100, progress)));
        }
        TextView textView = this.dumpMessageView;
        if (textView != null) {
            textView.setText(message);
        }
    }

    private void dismissDumpDialog() {
        AlertDialog alertDialog = this.dumpDialog;
        if (alertDialog == null) {
            return;
        }
        alertDialog.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String resolveDumpMessage(DumpStatus status) {
        if ("error".equals(status.state)) {
            return status.message.isEmpty() ? "Process failed." : status.message;
        }
        if ("done".equals(status.state)) {
            return "Dump complete";
        }
        return "Dumping JSON...";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public DumpStatus readDumpStatus(String packageName) {
        File statusFile = new File(getDumpOutputDir(packageName), "pairip_status.json");
        if (!statusFile.exists()) {
            return null;
        }
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(statusFile), StandardCharsets.UTF_8));
            try {
                StringBuilder builder = new StringBuilder();
                while (true) {
                    String line = reader.readLine();
                    if (line != null) {
                        builder.append(line);
                    } else {
                        JSONObject jsonObject = new JSONObject(builder.toString());
                        DumpStatus fromJson = DumpStatus.fromJson(jsonObject);
                        reader.close();
                        return fromJson;
                    }
                }
            } finally {
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void clearDumpFiles(String packageName) {
        File outputDir = getDumpOutputDir(packageName);
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        deleteIfExists(new File(outputDir, "pairip_dump.json"));
        deleteIfExists(new File(outputDir, "pairip_status.json"));
        deleteIfExists(new File(outputDir, packageName + "_patched.apk"));
    }

    private File getDumpOutputDir(String packageName) {
        return new File(Environment.getExternalStorageDirectory(), "Pairip/" + packageName);
    }

    private void deleteIfExists(File file) {
        if (file.exists()) {
            file.delete();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showPatchSuccessDialog(File dumpFile, File outputFile) {
        new AlertDialog.Builder(this).setTitle("Patch completed").setMessage("Dump JSON:\n" + dumpFile.getAbsolutePath() + "\n\nPatched APK:\n" + outputFile.getAbsolutePath()).setPositiveButton("CONFIRM", (DialogInterface.OnClickListener) null).show();
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this).setTitle("Process failed").setMessage(message).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
    }

    private void loadUserApps() {
        t(this, "Scanning for PairIP Protected Apps...");
        new Thread(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m108lambda$loadUserApps$12$comrevdexaantikactivityMainActivity();
            }
        }).start();
    }

    /* renamed from: lambda$loadUserApps$12$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m108lambda$loadUserApps$12$comrevdexaantikactivityMainActivity() {
        PackageManager pm;
        PackageManager pm2 = getPackageManager();
        List<ApplicationInfo> installedApps = pm2.getInstalledApplications(128);
        final List<AppAdapter.AppItem> filteredList = new ArrayList<>();
        for (ApplicationInfo appInfo : installedApps) {
            if ((appInfo.flags & 1) == 0) {
                if (!"com.pairip.application.Application".equals(appInfo.className)) {
                    pm = pm2;
                } else {
                    String name = appInfo.loadLabel(pm2).toString();
                    String packageName = appInfo.packageName;
                    Drawable icon = appInfo.loadIcon(pm2);
                    boolean installed = BlackBoxCore.get().isInstalled(packageName, 0);
                    pm = pm2;
                    filteredList.add(new AppAdapter.AppItem(name, packageName, icon, installed, appInfo.sourceDir, appInfo.splitSourceDirs));
                }
                pm2 = pm;
            }
        }
        runOnUiThread(new Runnable() { // from class: com.revdex.aantik.activity.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m107lambda$loadUserApps$11$comrevdexaantikactivityMainActivity(filteredList);
            }
        });
    }

    /* renamed from: lambda$loadUserApps$11$com-revdex-aantik-activity-MainActivity, reason: not valid java name */
    /* synthetic */ void m107lambda$loadUserApps$11$comrevdexaantikactivityMainActivity(List filteredList) {
        this.appList.clear();
        this.appList.addAll(filteredList);
        this.adapter.notifyDataSetChanged();
        if (this.appList.isEmpty()) {
            t(this, "No PairIP protected apps found.");
        } else {
            t(this, "Found " + this.appList.size() + " protected apps.");
        }
    }

    private void refreshList() {
        for (AppAdapter.AppItem item : this.appList) {
            item.setInstalled(BlackBoxCore.get().isInstalled(item.getPackageName(), 0));
        }
        this.adapter.notifyDataSetChanged();
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.setData(Uri.parse(String.format("package:%s", getPackageName())));
                    startActivity(intent);
                    return;
                } catch (Exception e) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION");
                    startActivity(intent2);
                    return;
                }
            }
            return;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 100);
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == 0) {
                t(this, "Storage permission granted");
            } else {
                t(this, "Storage permission denied");
            }
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        stopDumpStatusPolling();
        this.dumpExecutor.shutdownNow();
        super.onDestroy();
    }

    private static void t(Context context, String text) {
        TextView aa = new TextView(context);
        aa.setText(text);
        aa.setPadding(20, 10, 20, 10);
        aa.setTextSize(15.0f);
        aa.setTextColor(Color.parseColor("#303030"));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#FAFAFA"));
        gd.setCornerRadii(new float[]{10.0f, 10.0f, 0.0f, 0.0f, 10.0f, 10.0f, 0.0f, 0.0f});
        gd.setStroke(4, Color.parseColor("#303030"), 2.0f, 2.0f);
        aa.setBackground(gd);
        Toast rrr = new Toast(context);
        rrr.setDuration(1);
        rrr.setView(aa);
        rrr.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class DumpStatus {
        private final String message;
        private final int progress;
        private final String state;

        private DumpStatus(String state, int progress, String message) {
            this.state = state;
            this.progress = progress;
            this.message = message;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean isFinished() {
            return "done".equals(this.state) || "error".equals(this.state);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static DumpStatus fromJson(JSONObject jsonObject) {
            return new DumpStatus(jsonObject.optString("state"), jsonObject.optInt(NotificationCompat.CATEGORY_PROGRESS), jsonObject.optString("message"));
        }
    }

    // =====================================================================
    //  Side menu (drawer) + developer credit + channels
    // =====================================================================

    private void setupSideMenu() {
        try {
            setupSideMenuInternal();
        } catch (Throwable ignored) {
        }
    }

    private void setupSideMenuInternal() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer == null) {
            return;
        }
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.ma_nav_open, R.string.ma_nav_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void closeDrawer() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer != null) {
            drawer.closeDrawers();
        }
    }

    /** Handles every clickable row of the drawer and the hero button (android:onClick). */
    public void onMenuClick(View view) {
        try {
            handleMenuClick(view);
        } catch (Throwable ignored) {
        }
    }

    private void handleMenuClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_pick_file || id == R.id.ma_nav_pick) {
            closeDrawer();
            return;
        } else if (id == R.id.ma_nav_telegram) {
            closeDrawer();
            openLink("https://t.me/editortrue");
        } else if (id == R.id.ma_nav_youtube) {
            closeDrawer();
            openLink("https://www.youtube.com/@editortrue");
        } else if (id == R.id.ma_nav_about) {
            closeDrawer();
            showAbout();
        }
    }

    private void openLink(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.ma_about_title)
                .setMessage(R.string.ma_about_msg)
                .setPositiveButton(R.string.ma_ok, null)
                .show();
    }

    /** Cancels the running dump/patch session and reports the error to the user. */
    private void failDump(String message) {
        stopDumpStatusPolling();
        this.activeDumpPackage = null;
        this.dumpStartTimeMs = 0L;
        dismissDumpDialog();
        showErrorDialog(message);
    }
}
