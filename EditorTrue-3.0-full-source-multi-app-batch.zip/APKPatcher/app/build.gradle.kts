plugins {
    id("com.android.application") version "8.2.2"
    id("org.jetbrains.kotlin.android") version "1.9.22"
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.22"
}

android {
    namespace = "com.rktechno.apkpatcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.editortrue.patcher"
        minSdk = 21
        targetSdk = 34
        versionCode = 30
        versionName = "3.0.0"

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL3.bin.properties"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL1.bin.properties"
            pickFirsts += "org/bouncycastle/pqc/crypto/picnic/lowmcL5.bin.properties"
            pickFirsts += "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
        }
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.fragment:fragment-ktx:1.6.2")

    // الأداة الأصلية APKPatcher-1.0.0.jar (dexlib2 + ARSCLib + apksig + الباتشات المضمّنة + assets/hooks)
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))

    // APK analysis: read manifest / package name without JVM tools
    implementation("net.dongliu:apk-parser:2.6.10")

    // APK signing (V1/V2/V3) مضمّنة داخل apkpatcher-tool.jar (نفس apksig)
    // ملاحظة: لا تُفعّل com.android.tools.build:apksig هنا لتفادي تعارض classes مزدوجة

    // ZIP: zip4j supports split/xapk extraction utilities
    implementation("net.lingala.zip4j:zip4j:2.11.5")

    // Regex engine identical behavior on Android
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // SRPatch-X native APK builder and JSON configuration support.
    implementation("com.android.tools.build:apkzlib:9.1.0") {
        exclude(group = "com.android.tools.build", module = "apksig")
    }
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")

    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")


}
