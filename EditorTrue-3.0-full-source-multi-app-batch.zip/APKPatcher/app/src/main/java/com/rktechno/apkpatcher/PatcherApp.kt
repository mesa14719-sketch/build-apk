package com.rktechno.apkpatcher

import android.app.Application

class PatcherApp : Application()
