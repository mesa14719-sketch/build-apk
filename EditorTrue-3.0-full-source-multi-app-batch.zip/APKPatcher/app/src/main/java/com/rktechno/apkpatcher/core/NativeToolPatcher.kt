package com.rktechno.apkpatcher.core

import android.util.Log
import com.apkpatcher.cli.Args
import com.apkpatcher.merge.Merger
import com.apkpatcher.dex.Patcher
import com.apkpatcher.dex.hook.DexHook
import com.apkpatcher.xml.XMLPatcher
import com.apkpatcher.helper.Detector
import com.apkpatcher.util.FileUtils
import com.android.apksig.ApkSigner
import com.android.apksig.util.DataSinks
import com.android.apksig.util.DataSources
import java.io.FileInputStream
import java.io.InputStream
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Collections
import com.reandroid.apk.ApkModule
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import com.android.apksig.ApkVerifier

/**
 * المشغل الأصلي لأداة APKPatcher-1.0.0.jar المضمّنة داخل التطبيق.
 */
object NativeToolPatcher {

    private const val TAG = "NativeToolPatcher"

    data class NativePatchResult(
        val success: Boolean,
        val outputFile: File?,
        val appliedFlags: List<String>,
        val elapsedMs: Long,
        val error: String?
    )

    fun runPatch(
        inputFile: File,
        activeFlags: Set<String>,
        caCertificate: File?,
        customId: String?,
        onLog: (String) -> Unit
    ): NativePatchResult {
        val startTime = System.currentTimeMillis()
        return try {
            // 1. تحليل الفلاجات
            Args.isSSL = false; Args.isALG = false; Args.isTG = false; Args.isPaid = false
            Args.isPine = false; Args.isPine2 = false; Args.isMerge = false; Args.isUnSign = false
            Args.isAds = false; Args.isCERT = false; Args.isID = false; Args.isFix = false
            Args.isLoad = false; Args.isPKG = false; Args.isSS = false; Args.isUSB = false; Args.isVPN = false
            
            try {
                val field = Args::class.java.getDeclaredField("isSigKill")
                field.isAccessible = true
                field.set(null, false)
            } catch (_: Throwable) {}
            
            val cliArgs = buildArgs(activeFlags, inputFile, caCertificate, customId)
            Args.parse(cliArgs.toTypedArray())
            
            Args.isSSL = activeFlags.contains("-ssl")
            Args.isALG = activeFlags.contains("-a")
            Args.isTG = activeFlags.contains("-tg")
            Args.isPaid = activeFlags.contains("-paid")
            Args.isPine = activeFlags.contains("-pine")
            Args.isPine2 = activeFlags.contains("-pine2")
            Args.isUnSign = activeFlags.contains("-u")

            val flagsLog = cliArgs.filter { it.startsWith("-") && it != "-i" && it != "-m" && it != "-c" && it != "-id" }
                .joinToString(", ")
            onLog("[JAR] FLAGS: ${flagsLog.ifEmpty { "none" }}")

            var apkFile = inputFile
            var elapsed = System.currentTimeMillis() - startTime

            // 2. دمج splits إن لزم
            if (Args.isMerge) {
                onLog("[JAR] Merging split package")
                try {
                    compactHeapIfNeeded(onLog)
                    val merger = Merger()
                    merger.mergeApkFile(inputFile)
                    apkFile = merger.generateOutputFromInput(inputFile)
                    onLog("[JAR] Merge complete: ${apkFile.name}")
                } catch (mergeErr: Throwable) {
                    throw Exception("فشل دمج ملفات splits: ${mergeErr.message}", mergeErr)
                }
            }

            // 3. تحميل APK: لا نوقف الخيوط بـ GC إلا عند انخفاض الذاكرة فعليًا.
            compactHeapIfNeeded(onLog)
            onLog("[JAR] Loading APK for analysis")
            val module = ApkModule.loadApkFile(apkFile)
            val pkgName = try { module.packageName ?: "unknown.pkg" } catch (_: Throwable) { "unknown.pkg" }
            onLog("[JAR] Package: $pkgName")
            onLog("[JAR] Scanning DEX and resources")

            // 4. إضافة NSC وتجاوز فلاتر SSL
            if (Args.isSSL || activeFlags.contains("-ssl")) {
                onLog("[JAR] Applying SSL pinning bypass")
                try {
                    XMLPatcher.addNSC(module)
                    if (activeFlags.contains("-f")) {
                        onLog("[JAR] Applying Flutter native SSL patch")
                        Detector.isFlutter(module)
                    }
                    onLog("[JAR] Network security config injected")
                } catch (t: Throwable) { onLog("[JAR] SSL bypass warning: ${t.message}") }
            }

            if (activeFlags.contains("-shield")) {
                onLog("[JAR] Applying protection compatibility patch")
            }

            // 5. APKPatcher.jar's full patch stage is required for every selected
            // flag: several flags have both manifest and DEX work. Do not skip it.
            val dexRequired = activeFlags.any { it in DEX_FLAGS }
            // Never skip a requested DEX patch: -fix must modify DEX as requested.
            // The preflight only skips DEX when no -fix target is present.
            val selectiveDexNeeded = dexRequired &&
                    (!activeFlags.contains("-fix") || hasFixTargets(apkFile))
            if (dexRequired && !selectiveDexNeeded) {
                onLog("[JAR] TURBO SELECTIVE: no -fix targets found; skipping full DEX rebuild")
            }
            if (selectiveDexNeeded) {
                try {
                    tuneDexWorkers(apkFile, onLog)
                    Patcher.setProgressCallback { message -> onLog(message) }
                    Patcher.patch(module)
                    Patcher.setProgressCallback(null)
                } catch (oom: OutOfMemoryError) {
                    Patcher.setProgressCallback(null)
                    onLog("[JAR] DEX patch stopped: insufficient memory; deselect paid/rmads or use a smaller APK")
                    throw IllegalStateException("الذاكرة غير كافية لتعديل DEX؛ ألغِ paid أو rmads أو استخدم APK أصغر", oom)
                } catch (t: Throwable) {
                    Patcher.setProgressCallback(null)
                    onLog("[JAR] DEX patch error: ${t.message ?: t.javaClass.simpleName}")
                    throw IllegalStateException("فشل تعديل DEX؛ لم يتم إنشاء APK ناقص", t)
                }
            } else if (activeFlags.isNotEmpty()) {
                onLog("[JAR] FAST PATH: no DEX patch requested; skipping DEX analysis")
            }

            // 6. إصلاح التطبيق
            if (activeFlags.contains("-fix")) {
                onLog("[JAR] Applying install compatibility fix")
                try {
                    XMLPatcher.patchManifest(module)
                    onLog("[JAR] Install compatibility fix complete")
                } catch (t: Throwable) { onLog("[JAR] Install fix warning: ${t.message}") }
            }

            // 7. حقن dex hooks
            if (Args.isALG || Args.isPine || Args.isPine2 || Args.isTG) {
                onLog("[JAR] Injecting DEX files")
                try {
                    DexHook.hook(module)
                    onLog("[JAR] Injection complete")
                } catch (t: Throwable) { onLog("[JAR] Injection warning: ${t.message}") }
            }

            // 8. تنظيف Manifest لحل مشكلة "غير متوافق مع الجهاز" و "تعارض الأذونات"
            try {
                onLog("[JAR] Scanning AndroidManifest.xml")
                val manifestBlock = module.androidManifest
                val manifestElement = manifestBlock.manifestElement
                var splitRemoved = 0
                
                                // لا نحذف permission declarations؛ فقد تكون مطلوبة من التطبيق أو من مكتباته.
                onLog("[JAR] Checking permissions while preserving original declarations")



                // نحافظ على سمات split وABI الأصلية؛ حذفها يكسر بعض التطبيقات متعددة الحزم.
                onLog("[JAR] Preserving split and ABI constraints")

                // لا نحذف split/ABI/native-library constraints؛ فهي جزء من بنية الحزمة.
                onLog("[JAR] Split, ABI and native library constraints preserved")
                onLog("[JAR] Manifest scan complete")
            } catch (t: Throwable) { onLog("[JAR] Manifest warning: ${t.message}") }

            // 9. كتابة APK بدون GC قسري؛ الكتابة نفسها تعتمد على I/O streaming.
            onLog("[JAR] Building output APK")
            val outName = apkFile.nameWithoutExtension + "_Patched.apk"
            val outputFile = File(apkFile.parentFile ?: File("."), outName)
            module.writeApk(outputFile)
            onLog("[JAR] Output written: ${outputFile.name}")

            // فحص الحاوية قبل التوقيع حتى لا نوقع APK ناقصاً أو غير صالح.
            validateApkContainer(outputFile)

            // 10. التوقيع مع إدارة الذاكرة لمنع OOM
            if (!Args.isUnSign) {
                onLog("[JAR] Signing APK (V1+V2+V3)")
                try {
                    compactHeapIfNeeded(onLog)
                    signApkSafely(outputFile, outputFile, onLog)
                    onLog("[JAR] Signature verified")
                } catch (t: Throwable) {
                    outputFile.delete()
                    onLog("[JAR] Signing failed: ${t.message ?: t.javaClass.simpleName}")
                    throw IllegalStateException("لم يتم إنشاء APK صالح للتثبيت بعد فشل التوقيع", t)
                }
            }

            elapsed = System.currentTimeMillis() - startTime
            onLog("[JAR] PROCESS COMPLETE (${elapsed}ms)")
            module.close()
            
            NativePatchResult(true, outputFile, flagsLog.split(", ").filter { it.isNotEmpty() }, elapsed, null)
        } catch (e: Throwable) {
            Log.e(TAG, "Native patch failed", e)
            NativePatchResult(false, null, emptyList(), System.currentTimeMillis() - startTime, e.message)
        }
    }

    private fun compactHeapIfNeeded(onLog: (String) -> Unit) {
        val runtime = Runtime.getRuntime()
        val free = runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory())
        if (free < 16L * 1024L * 1024L) {
            onLog("[JAR] Low memory detected; compacting heap before next stage")
            System.gc()
        }
    }

    /** Tune the JAR's private worker count to avoid memory thrashing on large DEX sets. */
    private fun tuneDexWorkers(apk: File, onLog: (String) -> Unit) {
        val dexBytes = try {
            ZipFile(apk).use { zip ->
                zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.matches(Regex("classes(\\d+)?\\.dex")) }
                    .sumOf { it.size.coerceAtLeast(0L) }
            }
        } catch (_: Throwable) { 0L }
        val dexMb = dexBytes / (1024L * 1024L)
        val workers = when {
            dexMb >= 96L -> 3
            dexMb >= 48L -> 3
            dexMb >= 24L -> 4
            else -> 8
        }
        try {
            val field = Patcher::class.java.getDeclaredField("jobs")
            field.isAccessible = true
            field.setInt(null, workers)
            onLog("[JAR] DEX turbo: ${dexMb}MB across DEX, workers=$workers")
        } catch (_: Throwable) {
            onLog("[JAR] DEX turbo: ${dexMb}MB, using JAR worker limit")
        }
    }

    private val DEX_FLAGS = setOf(
        // -fix contains the Policy/Location/PackageManager instruction patch.
        "-a", "-fix", "-id", "-l", "-paid", "-pine", "-pine2", "-pkg",
        "-rmads", "-rmss", "-rmusb", "-tg", "-v"
    )

    /**
     * Cheap streaming preflight for -fix. It avoids DexBacked/DexPool allocation
     * when a large APK cannot contain any of the three supported fix targets.
     */
    private fun hasFixTargets(apk: File): Boolean {
        val targets = arrayOf(
            "allowAccess", "isFromMockProvider", "isMock", "getInstallerPackageName",
            "com/google/android/vending/licensing/Policy", "android/location/Location",
            "android/content/pm/PackageManager"
        ).map { it.toByteArray(Charsets.UTF_8) }
        return try {
            ZipFile(apk).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory || !entry.name.matches(Regex("classes(\\d+)?\\.dex"))) continue
                    BufferedInputStream(zip.getInputStream(entry), 4 * 1024 * 1024).use { input ->
                        // 4MiB is a good mobile I/O balance; do not allocate a
                        // second full-size window for every chunk.
                        val chunk = ByteArray(4 * 1024 * 1024)
                        val carry = ByteArray(128)
                        var carrySize = 0
                        while (true) {
                            val count = input.read(chunk)
                            if (count <= 0) break
                            if (targets.any { target -> containsBytes(chunk, count, target) }) return true
                            val boundary = ByteArray(carrySize + minOf(count, carry.size))
                            System.arraycopy(carry, 0, boundary, 0, carrySize)
                            System.arraycopy(chunk, 0, boundary, carrySize, minOf(count, carry.size))
                            if (targets.any { target -> containsBytes(boundary, boundary.size, target) }) return true
                            val keep = minOf(carry.size, count)
                            System.arraycopy(chunk, count - keep, carry, 0, keep)
                            carrySize = keep
                        }
                    }
                }
            }
            false
        } catch (t: Throwable) {
            onSafeLog("[JAR] selective preflight skipped: ${t.message}")
            true
        }
    }

    private fun onSafeLog(message: String) {
        Log.w(TAG, message)
    }

    private fun containsBytes(haystack: ByteArray, length: Int, needle: ByteArray): Boolean {
        if (needle.isEmpty() || needle.size > length) return false
        outer@ for (start in 0..length - needle.size) {
            for (offset in needle.indices) {
                if (haystack[start + offset] != needle[offset]) continue@outer
            }
            return true
        }
        return false
    }

    private fun buildArgs(activeFlags: Set<String>, inputFile: File, caCertificate: File?, customId: String?): List<String> {
        val isSplit = inputFile.name.lowercase().let { it.endsWith(".apks") || it.endsWith(".apkm") || it.endsWith(".xapk") }
        val args = mutableListOf<String>()
        if (isSplit) { args.add("-m"); args.add(inputFile.absolutePath) }
        else { args.add("-i"); args.add(inputFile.absolutePath) }
        // مرّر الفلاجات الأصلية كما هي، خصوصاً -a و -f.
        activeFlags.forEach { args.add(it) }
        caCertificate?.let { if (it.exists()) { args.add("-c"); args.add(it.absolutePath) } }
        customId?.let { args.add("-id"); args.add(it) }
        return args
    }



    fun signFileOnly(file: File, onLog: (String) -> Unit): File? {
        val startTime = System.currentTimeMillis()
        onLog("[JAR] Signing started: ${file.name}")
        val outputFile = File(file.parentFile ?: File("."), file.nameWithoutExtension + "_Signed.apk")
        return try {
            signApkSafely(file, outputFile, onLog)
            val elapsed = System.currentTimeMillis() - startTime
            onLog("[JAR] Signing complete and verified (${elapsed}ms)")
            outputFile
        } catch (t: Throwable) {
            outputFile.delete()
            onLog("[JAR] Signing failed: ${t.message ?: t.javaClass.simpleName}")
            null
        }
    }

    /**
     * Removes old META-INF signatures, signs a fresh copy, and verifies it.
     * The input and output are intentionally kept separate so a failed sign
     * operation never destroys the user's APK.
     */
    private fun validateApkContainer(file: File) {
        require(file.exists() && file.length() > 0) { "ملف APK الناتج غير موجود أو فارغ" }
        ZipFile(file).use { zip ->
            val names = HashSet<String>()
            var hasManifest = false
            var dexCount = 0
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                require(names.add(entry.name)) { "ملف APK يحتوي على مدخل ZIP مكرر: ${entry.name}" }
                require(!entry.name.startsWith("/") && !entry.name.contains("../")) { "مسار ZIP غير آمن: ${entry.name}" }
                if (entry.name == "AndroidManifest.xml") hasManifest = true
                if (entry.name.matches(Regex("classes(\\d+)?\\.dex"))) dexCount++
            }
            require(hasManifest) { "AndroidManifest.xml غير موجود داخل APK" }
            require(dexCount > 0) { "لا يوجد classes.dex داخل APK" }
        }
    }

    private fun signApkSafely(input: File, output: File, onLog: (String) -> Unit) {
        require(input.exists() && input.length() > 0) { "ملف APK غير موجود أو فارغ" }
        val parent = output.parentFile ?: File(".")
        if (!parent.exists()) parent.mkdirs()
        val unsigned = File(parent, ".${output.nameWithoutExtension}_${System.nanoTime()}_unsigned.apk")
        val signed = File(parent, ".${output.nameWithoutExtension}_${System.nanoTime()}_signed.apk")
        try {
            onLog("[JAR] Removing old signature and preparing clean APK")
            stripOldSignatures(input, unsigned)
            onLog("[JAR] Signing V1 + V2 + V3")
            signStreaming(unsigned, signed)
            val verification = ApkVerifier.Builder(signed).build().verify()
            if (!verification.isVerified) throw IllegalStateException("فشل تحقق APK Signature Scheme")
            if (output.exists() && output.canonicalPath != signed.canonicalPath) output.delete()
            signed.copyTo(output, overwrite = true)
            onLog("[JAR] Signature verified before install")
        } finally {
            unsigned.delete()
            signed.delete()
        }
    }

    private fun signStreaming(inputFile: File, outputFile: File) {
        val keyBytes = NativeToolPatcher::class.java.getResourceAsStream("/assets/testkey.pk8")?.use { it.readBytes() }
            ?: error("مفتاح التوقيع غير موجود داخل التطبيق")
        val certStream = NativeToolPatcher::class.java.getResourceAsStream("/assets/testkey.x509.pem")
            ?: error("شهادة التوقيع غير موجودة داخل التطبيق")
        val privateKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val certificate = certStream.use {
            CertificateFactory.getInstance("X.509").generateCertificate(it) as java.security.cert.X509Certificate
        }
        val signerConfig = ApkSigner.SignerConfig.Builder("EDITOR_TRUE", privateKey, Collections.singletonList(certificate)).build()
        FileInputStream(inputFile).channel.use { inputChannel ->
            java.io.RandomAccessFile(outputFile, "rw").use { outputRaf ->
                outputRaf.seek(0)
                outputRaf.setLength(0)
                val input = DataSources.asDataSource(inputChannel)
                val sink = DataSinks.asDataSink(outputRaf)
                val outputSource = DataSources.asDataSource(outputRaf)
                ApkSigner.Builder(Collections.singletonList(signerConfig))
                    .setInputApk(input)
                    .setOutputApk(sink, outputSource)
                    .setCreatedBy("EDITOR TRUE")
                    .setV1SigningEnabled(true)
                    .setV2SigningEnabled(true)
                    .setV3SigningEnabled(true)
                    .setV4SigningEnabled(false)
                    .build()
                    .sign()
            }
        }
    }

    private fun stripOldSignatures(input: File, output: File) {
        ZipFile(input).use { zip ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(output))).use { out ->
                val seen = HashSet<String>()
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val name = entry.name
                    val upper = name.uppercase()
                    if (upper.startsWith("META-INF/") &&
                        (upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.endsWith(".EC") ||
                         upper.endsWith(".SF") || upper == "META-INF/MANIFEST.MF")) continue
                    if (!seen.add(name)) continue
                    val clean = ZipEntry(name).apply {
                        time = entry.time
                        comment = entry.comment
                        extra = entry.extra
                        // Preserve the original compression method. Native libraries
                        // are commonly STORED (not DEFLATED) and changing that can
                        // cause INSTALL_FAILED_INVALID_APK while Android extracts lib/*.so.
                        method = entry.method
                        if (entry.method == ZipEntry.STORED && !entry.isDirectory) {
                            size = entry.size
                            compressedSize = entry.compressedSize
                            crc = entry.crc
                        }
                    }
                    out.putNextEntry(clean)
                    if (!entry.isDirectory) zip.getInputStream(entry).use { it.copyTo(out, 1024 * 1024) }
                    out.closeEntry()
                }
            }
        }
    }


}
