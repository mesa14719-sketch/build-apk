package com.rktechno.apkpatcher.ui

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.WindowManager
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.rktechno.apkpatcher.BuildConfig
import com.rktechno.apkpatcher.R
import android.content.BroadcastReceiver
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.rktechno.apkpatcher.core.PatchService
import com.rktechno.apkpatcher.core.PatcherFlags
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.navigation.NavigationView
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File


/**
 * الشاشة الرئيسية للتطبيق - نظير أوامر /start و /flags ومعالجة المستندات في البوت.
 *
 * تدفق العمل:
 * 1. المستخدم يختار ملف APK/APKS/XAPK/APKM
 * 2. يفعّل الفلاجات المطلوبة من القائمة (تماماً كبوت تيليجرام)
 * 3. يضغط "بدء المعالجة" فتبدأ مراحل الفك → الباتش → إعادة التجميع → التوقيع
 * 4. تظهر النتيجة مع خيار التثبيت أو المشاركة
 */
class MainActivity : AppCompatActivity() {

    private val viewModel: PatcherViewModel by viewModels()
    
    private val toolbar by lazy { findViewById<MaterialToolbar>(R.id.toolbar) }
    private val drawerLayout by lazy { findViewById<DrawerLayout>(R.id.drawerLayout) }
    private val navView by lazy { findViewById<NavigationView>(R.id.navView) }
    private val rvFlags by lazy { findViewById<RecyclerView>(R.id.rvFlags) }
    private val rvLogs by lazy { findViewById<RecyclerView>(R.id.rvLogs) }
    private val btnCopyLogs by lazy { findViewById<MaterialButton>(R.id.btnCopyLogs) }
    private val btnSelectFile by lazy { findViewById<MaterialButton>(R.id.btnSelectFile) }
    private val btnResetFlags by lazy { findViewById<MaterialButton>(R.id.btnResetFlags) }
    private val btnShowCmd by lazy { findViewById<MaterialButton>(R.id.btnShowCmd) }
    private val btnSelectCert by lazy { findViewById<MaterialButton>(R.id.btnSelectCert) }
    private val btnSetModule by lazy { findViewById<MaterialButton>(R.id.btnSetModule) }
    private val btnStart by lazy { findViewById<MaterialButton>(R.id.btnStart) }
    private val btnAbout by lazy { findViewById<MaterialButton>(R.id.btnAbout) }
    private val btnModifiedApps by lazy { findViewById<MaterialButton>(R.id.btnModifiedApps) }
    private val btnInstall by lazy { findViewById<MaterialButton>(R.id.btnInstall) }
    private val btnShare by lazy { findViewById<MaterialButton>(R.id.btnShare) }
    private val tvFileName by lazy { findViewById<TextView>(R.id.tvFileName) }
    private val tvFileSize by lazy { findViewById<TextView>(R.id.tvFileSize) }
    private val tvCurrentStep by lazy { findViewById<TextView>(R.id.tvCurrentStep) }
    private val progressBar by lazy { findViewById<LinearProgressIndicator>(R.id.progressBar) }
    private val tvProgressPercent by lazy { findViewById<TextView>(R.id.tvProgressPercent) }
    private val cardProgress by lazy { findViewById<MaterialCardView>(R.id.cardProgress) }
    private val cardResult by lazy { findViewById<MaterialCardView>(R.id.cardResult) }
    private val tvResultTitle by lazy { findViewById<TextView>(R.id.tvResultTitle) }
    private val tvOutputFile by lazy { findViewById<TextView>(R.id.tvOutputFile) }
    private val tvAppliedFlags by lazy { findViewById<TextView>(R.id.tvAppliedFlags) }
    private val tvTimeSpent by lazy { findViewById<TextView>(R.id.tvTimeSpent) }

    // Minimal adapter definitions to avoid missing class errors
    private lateinit var flagsAdapter: FlagsAdapter
    private lateinit var logsAdapter: LogsAdapter
    private var patchStartedAt = 0L
    private var mainExitWarning: android.app.AlertDialog? = null
    private var renderedLogCount = 0

    // منتقي الملفات - يدعم APK | APKS | XAPK | APKM
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) handleSelectedUris(uris)
    }

    // استقبال نتائج وسجلات الخدمة لحظياً
    private val resultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            when (intent.action) {
                PatchService.ACTION_LOG -> {
                    val msg = intent.getStringExtra(PatchService.EXTRA_LOG_MSG) ?: return
                    val progress = intent.getFloatExtra(PatchService.EXTRA_PROGRESS, -1f)
                    viewModel.updateLiveLog(msg, progress)
                }
                PatchService.ACTION_RESULT -> {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    mainExitWarning?.dismiss()
                    mainExitWarning = null
                    val success = intent.getBooleanExtra(PatchService.EXTRA_SUCCESS, false)
                    val outputPath = intent.getStringExtra(PatchService.EXTRA_OUTPUT_PATH)
                    val error = intent.getStringExtra(PatchService.EXTRA_ERROR)
                    val apkName = intent.getStringExtra(PatchService.EXTRA_APK_NAME) ?: ""
                    val elapsed = intent.getLongExtra(PatchService.EXTRA_ELAPSED, 0L)
                    if (success && outputPath != null) {
                        viewModel.patchFinished(success = true, outputFile = File(outputPath), apkName = apkName, error = null, elapsedMs = elapsed)
                    } else {
                        viewModel.patchFinished(success = false, outputFile = null, apkName = apkName, error = error, elapsedMs = elapsed)
                    }
                }
            }
        }
    }

    // منتقي شهادة CA
    private val certPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleSelectedCert(it) }
    }

    override fun attachBaseContext(newBase: Context) {
        val langCode = newBase.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getString("lang", "ar") ?: "ar"
        val locale = java.util.Locale(langCode)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupToolbar()
        setupFlagsRecyclerView()
        setupLogsRecyclerView()
        setupClickListeners()
        observeState()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewModel.state.value.isProcessing) {
                    Toast.makeText(this@MainActivity, "لا تخرج الآن: Editor True ما زال يعدّل التطبيق", Toast.LENGTH_LONG).show()
                    mainExitWarning?.show()
                } else {
                    finish()
                }
            }
        })
        
        try {
            val filter = android.content.IntentFilter().apply {
                addAction(PatchService.ACTION_RESULT)
                addAction(PatchService.ACTION_LOG)
            }
            registerReceiver(
                resultReceiver,
                filter,
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) Context.RECEIVER_NOT_EXPORTED else 0
            )
        } catch (e: Exception) {
            android.util.Log.w("APKPatcher", "تعذر تسجيل مستقبل البث: ${e.message}")
        }
    }

    override fun onResume() {
        super.onResume()
        // فحص الصلاحية إجبارياً عند كل عودة للتطبيق
        if (!hasStoragePermission()) {
            showMandatoryPermissionDialog()
        }
        pendingInstallFile?.let { file ->
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || packageManager.canRequestPackageInstalls()) {
                pendingInstallFile = null
                lifecycleScope.launch(Dispatchers.Main) {
                    kotlinx.coroutines.delay(300)
                    executeSystemInstall(file)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(resultReceiver)
        } catch (_: Exception) {}
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.app_name)
        toolbar.setNavigationOnClickListener {
            if (viewModel.state.value.isProcessing) {
                Toast.makeText(this, "اترك Editor True مفتوحًا حتى يكتمل التعديل", Toast.LENGTH_LONG).show()
                mainExitWarning?.show()
            } else drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }
        setupDrawerNavigation()
    }

    private fun setupDrawerNavigation() {
        navView.setNavigationItemSelectedListener { menuItem ->
            if (viewModel.state.value.isProcessing) {
                Toast.makeText(this, "اترك Editor True مفتوحًا حتى يكتمل تعديل التطبيق", Toast.LENGTH_LONG).show()
                return@setNavigationItemSelectedListener false
            }
            drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // الصفحة الرئيسية نشطة بالفعل
                }
                R.id.nav_modified_apps -> {
                    showModifiedAppsDialog()
                }
                R.id.nav_editor_x -> {
                    startActivity(Intent(this, EditorXActivity::class.java))
                }
                R.id.nav_language -> {
                    showLanguageChoiceDialog()
                }
                R.id.nav_telegram -> {
                    openUrl("https://t.me/editortrue")
                }
                R.id.nav_youtube -> {
                    openUrl("https://youtube.com/@editortrue")
                }
                R.id.nav_about -> {
                    showAboutDialog()
                }

            }
            true
        }
    }



    /** Editor X profile integrated with EDITOR TRUE's existing safe background pipeline. */
    private fun showEditorXDialog() {
        val levels = arrayOf(
            "PMS Hook — توافق عالٍ",
            "IO + PMS Hook — حماية متوسطة",
            "More Hook — حماية متقدمة",
            "Service Hook — أقوى وضع متوافق"
        )
        var selected = 3
        MaterialAlertDialogBuilder(this)
            .setTitle("Editor X")
            .setMessage("وضع Editor X المدمج داخل EDITOR TRUE. اختر مستوى المعالجة ثم حدّد ملف APK من الشاشة الرئيسية.\n\nيتم حفظ الناتج في مجلد EDITOR TRUE ولا يتم تعديل الملف الأصلي.")
            .setSingleChoiceItems(levels, selected) { _, which -> selected = which }
            .setPositiveButton("تفعيل الوضع") { _, _ ->
                // Reuse the existing tested pipeline; the original APK remains untouched.
                viewModel.resetFlags()
                viewModel.toggleFlag("-fix")
                if (selected >= 1) viewModel.toggleFlag("-pkg")
                if (selected >= 2) viewModel.toggleFlag("-shield")
                Snackbar.make(drawerLayout, "تم تفعيل ملف Editor X — المستوى ${selected + 1}", Snackbar.LENGTH_LONG).show()
                toolbar.title = "Editor X"
            }
            .setNeutralButton("About Editor X") { _, _ ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("عن Editor X")
                    .setMessage("تم دمج محرك Editor X داخل محرر EDITOR TRUE مع الحفاظ على واجهة التطبيق ومسار المعالجة الخلفية والتوقيع.\n\nاستخدم الأداة فقط على التطبيقات التي تملك حق اختبارها.")
                    .setPositiveButton("حسناً", null)
                    .show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showLanguageChoiceDialog() {
        val langs = arrayOf("العربية (Arabic)", "English (الإنجليزية)")
        MaterialAlertDialogBuilder(this)
            .setTitle("اختر لغة التطبيق / Select Language")
            .setItems(langs) { _, which ->
                val langCode = if (which == 0) "ar" else "en"
                setAppLanguage(langCode)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun setAppLanguage(langCode: String) {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        prefs.edit().putString("lang", langCode).apply()
        val locale = java.util.Locale(langCode)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(resources.configuration)
        config.setLocale(locale)
        createConfigurationContext(config)
        resources.updateConfiguration(config, resources.displayMetrics)
        
        // إعادة تشغيل التطبيق بالكامل من النشاط الرئيسي لضمان تحديث كل النصوص والقوائم فوراً
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }

    private fun setupFlagsRecyclerView() {
        flagsAdapter = FlagsAdapter { flagKey -> viewModel.toggleFlag(flagKey) }
        rvFlags.layoutManager = LinearLayoutManager(this)
        rvFlags.adapter = flagsAdapter
        refreshFlagsList()
    }

    private fun setupLogsRecyclerView() {
        logsAdapter = LogsAdapter()
        rvLogs.layoutManager = LinearLayoutManager(this)
        rvLogs.adapter = logsAdapter
    }

    private fun setupClickListeners() {
        // اختيار ملف APK - من الملفات أو التطبيقات المثبتة
        btnSelectFile.setOnClickListener {
            showSourceChoiceDialog()
        }

        // إعادة ضبط الفلاجات
        btnResetFlags.setOnClickListener {
            try {
                viewModel.resetFlags()
                if (::flagsAdapter.isInitialized) refreshFlagsList()
                Snackbar.make(drawerLayout, "تمت إعادة ضبط جميع الخيارات", Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.util.Log.e("APKPatcher", "فشل إعادة ضبط الباتشات", e)
                Toast.makeText(this, "تعذر إعادة ضبط الخيارات", Toast.LENGTH_SHORT).show()
            }
        }

        // معاينة الأمر النهائي (نظير show_cmd في البوت)
        btnShowCmd.setOnClickListener {
            val s = viewModel.state.value
            val flagsStr = s.activeFlags.sorted().joinToString(" ")
            val activeText = if (flagsStr.isBlank()) "لا توجد باتشات مفعلة" else flagsStr
            val cmd = "ملف الإدخال: ${s.apkName.ifEmpty { "<app_name>" }}\nالفلاجات المفعلة: $activeText\n\nالأمر: java -jar APKPatcher.jar -i ${s.apkName.ifEmpty { "<app_name>" }}${if (flagsStr.isBlank()) "" else " $flagsStr"}"
            MaterialAlertDialogBuilder(this)
                .setTitle("الأمر المطبق حالياً")
                .setMessage(cmd)
                .setPositiveButton("حسناً", null)
                .show()
        }

        btnCopyLogs.setOnClickListener {
            val logs = viewModel.state.value.logs.joinToString("\n")
            if (logs.isBlank()) {
                Toast.makeText(this, "لا توجد عمليات لنسخها بعد", Toast.LENGTH_SHORT).show()
            } else {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("EditorTrue operations", logs))
                Toast.makeText(this, "تم نسخ سجل العمليات بالكامل", Toast.LENGTH_SHORT).show()
            }
        }

        // اختيار شهادة CA (-c)
        btnSelectCert.setOnClickListener {
            certPickerLauncher.launch("*/*")
        }

        // إدخال مسار موديول (-l)
        btnSetModule.setOnClickListener {
            val input = android.widget.EditText(this).apply {
                hint = getString(R.string.enter_module_path)
                setPadding(48, 32, 48, 32)
            }
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.module_path))
                .setView(input)
                .setPositiveButton("تعيين") { _, _ ->
                    val path = input.text.toString().trim()
                    if (path.isNotEmpty()) {
                        viewModel.setModulePath(path)
                        Snackbar.make(drawerLayout, "${getString(R.string.module_set)}: $path", Snackbar.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        // بدء المعالجة (في الخدمة الخلفية)
        btnStart.setOnClickListener {
            val s = viewModel.state.value
            if (s.selectedApk == null) {
                Snackbar.make(drawerLayout, getString(R.string.no_file_selected), Snackbar.LENGTH_LONG).show()
                return@setOnClickListener
            }
            
            // التحقق من الصلاحية إجبارياً قبل البدء
            if (!hasStoragePermission()) {
                showMandatoryPermissionDialog()
                return@setOnClickListener
            }

            if (!ensureNotificationPermission()) return@setOnClickListener
            
            // التحقق من اختيار باتش واحد على الأقل
            if (viewModel.state.value.activeFlags.isEmpty()) {
                Toast.makeText(this, "⚠️ يرجى اختيار باتش واحد على الأقل قبل البدء", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // بدء المعالجة - الزر سيبقى متاحاً لعمليات أخرى
            patchStartedAt = System.currentTimeMillis()
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            mainExitWarning = android.app.AlertDialog.Builder(this)
                .setTitle("🚀 Editor True يعمل — لا تخرج")
                .setMessage("تجري الآن عمليات APKPatcher الفعلية. أبقِ الشاشة مفتوحة حتى تظهر رسالة اكتمال التعديل.")
                .setCancelable(false)
                .setPositiveButton("حسنًا، سأنتظر", null)
                .create()
                .also { it.show() }
            viewModel.startPatching()
            Toast.makeText(this, "🚀 بدأت المعالجة الفعلية", Toast.LENGTH_SHORT).show()
        }

        // عن التطبيق والحقوق
        btnAbout.setOnClickListener {
            showAboutDialog()
        }

        // إدارة التطبيقات المعدلة
        btnModifiedApps.setOnClickListener {
            showModifiedAppsDialog()
        }

        // تثبيت الملف الناتج
        btnInstall.setOnClickListener {
            val file = viewModel.state.value.result?.outputFile ?: return@setOnClickListener
            installApk(file)
        }

        // مشاركة الملف الناتج
        btnShare.setOnClickListener {
            val file = viewModel.state.value.result?.outputFile ?: return@setOnClickListener
            shareApk(file)
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                // تجميع تحديثات الخدمة كل 200ms يمنع إعادة رسم الواجهة لكل سطر سجل.
                viewModel.state.sample(200L).collect { state ->
                    try {
                    // تحديث بطاقة الملف
                    if (state.selectedApk != null) {
                        val name = if (state.apkName.isNotEmpty()) state.apkName else (state.selectedApk?.name ?: "غير معروف")
                        val size = if (state.apkSize > 0) viewModel.humanBytes(state.apkSize) else (state.selectedApk?.length()?.let { viewModel.humanBytes(it) } ?: "0 B")
                        
                        tvFileName.text = "الملف المحدد: $name"
                        tvFileSize.apply {
                            visibility = View.VISIBLE
                            text = "الحجم: $size"
                        }
                        btnSelectFile.text = "🔄 تغيير الملف"
                    } else {
                        tvFileName.text = "لم يتم اختيار أي ملف"
                        tvFileSize.visibility = View.GONE
                        btnSelectFile.text = "اختر ملف APK من الملفات"
                    }

                    // تحديث قائمة الفلاجات
                    refreshFlagsList()

                    // حالة المعالجة (نجعل كرت التقدم يظهر دائماً إذا كان هناك تقدم أو خطوة مسجلة لكي لا يختفي)
                    val showProgressCard = state.isProcessing || state.currentStep.isNotEmpty() || state.logs.isNotEmpty()
                    cardProgress.visibility = if (showProgressCard) View.VISIBLE else View.GONE
                    btnStart.isEnabled = !state.isProcessing && state.selectedApk != null
                    btnStart.text = if (state.isProcessing) "⏳ ${getString(R.string.processing)}" else getString(R.string.start_patching)
                    tvCurrentStep.text = if (state.currentStep.isNotEmpty()) state.currentStep else "جاهز للاستخدام"
                    progressBar.progress = (state.progress * 100).toInt().coerceIn(0, 100)
                    tvProgressPercent.text = "${(state.progress * 100).toInt().coerceIn(0, 100)}%"

                    // تحديث السجل
                    if (state.logs.isNotEmpty()) {
                        if (state.logs.size < renderedLogCount) {
                            logsAdapter.clear()
                            renderedLogCount = 0
                        }
                        val newLogs = state.logs.drop(renderedLogCount)
                        logsAdapter.addLogs(newLogs)
                        val shouldScroll = newLogs.isNotEmpty()
                        renderedLogCount = state.logs.size
                        if (shouldScroll) rvLogs.scrollToPosition(state.logs.size - 1)
                    }

                    // النتيجة
                    state.result?.let { result ->
                        cardResult.visibility = View.VISIBLE
                        tvResultTitle.text = if (result.success) {
                            "✅ ${getString(R.string.success)}"
                        } else {
                            "❌ ${getString(R.string.failed)}"
                        }
                        tvResultTitle.setTextColor(
                            getColor(if (result.success) R.color.success else R.color.error)
                        )
                        tvOutputFile.text = "${getString(R.string.output_file)} ${result.outputFile?.name ?: "-"}"
                        tvAppliedFlags.text = "${getString(R.string.applied_flags)} ${result.appliedFlags.joinToString(", ")}"
                        tvTimeSpent.text = "${getString(R.string.time_spent)} ${result.elapsedMs / 1000.0} ثانية"

                        if (!result.success) {
                            tvOutputFile.text = "السبب: ${result.errorMessage}"
                            btnInstall.visibility = View.GONE
                            btnShare.visibility = View.GONE
                        }
                    } ?: run {
                        cardResult.visibility = View.GONE
                    }
                    } catch (e: Exception) {
                        // أي خطأ في تحديث الواجهة (مثل مورد نص ناقص) لا يسبب كراش
                        android.util.Log.e("APKPatcher", "خطأ في تحديث الواجهة", e)
                    }
                }
            }
        }
    }

    private fun refreshFlagsList() {
        val activeFlags = viewModel.state.value.activeFlags
        flagsAdapter.updateData(activeFlags)
    }

    // ---------------------------------------------------------
    // اختيار من التطبيقات المثبتة أو من الملفات
    // ---------------------------------------------------------
    private fun showSourceChoiceDialog() {
        // اختيار الملفات فقط بناءً على طلب المستخدم
        filePickerLauncher.launch("*/*")
    }

    private fun ensureNotificationPermission(): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
                return false
            }
        }
        return true
    }

    // ---------------------------------------------------------
    // معالجة الملف المختار
    // ---------------------------------------------------------
    private fun handleSelectedUri(uri: Uri) {
        val fileName = getFileName(uri) ?: run {
            Toast.makeText(this, "تعذر قراءة اسم الملف", Toast.LENGTH_SHORT).show()
            return
        }

        // التحقق من الامتداد
        val lowerName = fileName.lowercase()
        val isValid = lowerName.endsWith(".apk") || lowerName.endsWith(".apks") ||
                lowerName.endsWith(".xapk") || lowerName.endsWith(".apkm")
        if (!isValid) {
            Toast.makeText(
                this,
                "❌ صيغة الملف غير مدعومة\nالصيغ المدعومة: .apk .apks .xapk .apkm",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // نسخ الملف إلى مجلد التطبيق الخاص باستخدام مخزن كبير للملفات الضخمة
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "input_apks").also { it.mkdirs() }
                val destFile = File(destDir, fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().buffered(1024 * 1024).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                }
                viewModel.selectApk(destFile)
                Toast.makeText(this@MainActivity, "✔ تم اختيار: $fileName", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "خطأ في قراءة الملف: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleSelectedUris(uris: List<Uri>) {
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "input_apks").also { it.mkdirs() }
                val paths = uris.mapNotNull { uri ->
                    val name = getFileName(uri) ?: return@mapNotNull null
                    val lower = name.lowercase()
                    if (!lower.endsWith(".apk") && !lower.endsWith(".apks") && !lower.endsWith(".xapk") && !lower.endsWith(".apkm")) return@mapNotNull null
                    val safe = File(destDir, name)
                    contentResolver.openInputStream(uri)?.use { input ->
                        safe.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) }
                    }
                    safe.absolutePath
                }
                if (paths.isEmpty()) {
                    Toast.makeText(this@MainActivity, "لم يتم اختيار ملفات APK صالحة", Toast.LENGTH_LONG).show()
                } else {
                    getSharedPreferences("patcher_batch", MODE_PRIVATE).edit()
                        .putString("paths", paths.joinToString("|||"))
                        .apply()
                    viewModel.selectApk(File(paths.first()))
                    Toast.makeText(this@MainActivity, "تم اختيار ${paths.size} تطبيقات — ستُعالج بالتتابع", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "خطأ في قراءة الملفات: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleSelectedCert(uri: Uri) {
        val fileName = getFileName(uri) ?: return
        val lower = fileName.lowercase()
        if (!lower.endsWith(".pem") && !lower.endsWith(".crt") && !lower.endsWith(".cert") && !lower.endsWith(".cer")) {
            Toast.makeText(this, "❌ صيغة الشهادة غير مدعومة\n(.pem/.crt/.cert)", Toast.LENGTH_LONG).show()
            return
        }
        lifecycleScope.launch {
            try {
                val destDir = File(filesDir, "certs").also { it.mkdirs() }
                val destFile = File(destDir, fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().buffered(1024 * 1024).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                }
                viewModel.setCaCertificate(destFile)
                Snackbar.make(drawerLayout, "✅ تم حفظ الشهادة وحقنها مع الفلاج -c", Snackbar.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "خطأ في قراءة الشهادة: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        if (name == null) {
            name = uri.lastPathSegment?.substringAfterLast("/")
        }
        return name
    }

    // ---------------------------------------------------------
    // تثبيت ومشاركة APK
    // ---------------------------------------------------------
    private var pendingInstallFile: File? = null

    private val uninstallLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // بعد محاولة إلغاء التثبيت عبر النظام، نتابع التثبيت فوراً
        pendingInstallFile?.let { file ->
            val f = file
            pendingInstallFile = null
            // تأخير بسيطة لضمان تحديث النظام
            lifecycleScope.launch(Dispatchers.Main) {
                kotlinx.coroutines.delay(500)
                executeSystemInstall(f)
            }
        }
    }

    private fun installApk(file: File) {
        // التحقق من صلاحية تثبيت التطبيقات من مصادر غير معروفة على أندرويد 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!packageManager.canRequestPackageInstalls()) {
                pendingInstallFile = file
                MaterialAlertDialogBuilder(this)
                    .setTitle("إذن التثبيت مطلوب")
                    .setMessage("يرجى السماح لتطبيق APK Patcher بتثبيت التطبيقات لتتمكن من تثبيت الملفات المعدلة.")
                    .setPositiveButton("الإعدادات") { _, _ ->
                        val intent = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                        startActivity(intent)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
                return
            }
        }

        // فحص حزمة الـ APK لمعرفة اسم الحزمة (Package Name) وهل هناك تعارض مع تطبيق مثبت بنفس الاسم وبتوقيع مختلف
        try {
            val pm = packageManager
            val pkgInfo = pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_ACTIVITIES)
            if (pkgInfo != null) {
                val targetPkgName = pkgInfo.packageName
                var isAlreadyInstalled = false
                try {
                    pm.getPackageInfo(targetPkgName, 0)
                    isAlreadyInstalled = true
                } catch (_: PackageManager.NameNotFoundException) {
                    isAlreadyInstalled = false
                }

                if (isAlreadyInstalled) {
                    pendingInstallFile = file
                    
                    // توجيه المستخدم مباشرة إلى صفحة معلومات التطبيق لحذفه يدوياً بكل سهولة
                    MaterialAlertDialogBuilder(this)
                        .setTitle("⚠️ التطبيق مثبت مسبقاً في جهازك")
                        .setMessage("لتجنب مشاكل التثبيت أو تعارض التوقيع، يرجى حذف النسخة القديمة أولاً.\n\nاضغط على زر (فتح معلومات التطبيق) أدناه، ثم اضغط على (إلغاء التثبيت):")
                        .setPositiveButton("⚙️ فتح معلومات التطبيق") { _, _ ->
                            try {
                                val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$targetPkgName"))
                                startActivity(intent)
                                Toast.makeText(this, "قم بإلغاء تثبيت النسخة القديمة ثم أعد تثبيت النسخة المعدلة", Toast.LENGTH_LONG).show()
                            } catch (e: Throwable) {
                                try {
                                    val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$targetPkgName"))
                                    startActivity(intent)
                                } catch (_: Throwable) {
                                    Toast.makeText(this, "يرجى حذف التطبيق يدوياً من إعدادات الهاتف", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                    return
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e("MainActivity", "خطأ في فحص حزمة الـ APK للتثبيت", t)
        }

        executeSystemInstall(file)
    }

    // تم إلغاء كود الروت بناءً على طلب المستخدم والاعتماد كلياً على Shizuku والتثبيت النظامي



    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun showMandatoryPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("🔓 صلاحية التخزين إجبارية")
            .setMessage("لن يعمل تطبيق EDITOR TRUE بدون صلاحية 'الوصول إلى جميع الملفات'.\n\nيرجى الضغط على 'تفعيل' ومنح الصلاحية للتطبيق من الإعدادات ليتمكن من حفظ تطبيقاتك المعدلة.")
            .setCancelable(false)
            .setPositiveButton("تفعيل الإذن") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        val intent = Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        intent.data = Uri.parse("package:$packageName")
                        startActivity(intent)
                    } else {
                        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 100)
                    }
                } catch (e: Exception) {
                    val intent = Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
            .setNegativeButton("إغلاق التطبيق") { _, _ -> finish() }
            .show()
    }

    private fun checkStoragePermission() {
        if (!hasStoragePermission()) {
            showMandatoryPermissionDialog()
        }
    }

    private fun launchNormalUninstall(targetPkgName: String) {
        val uninstallIntent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$targetPkgName")).apply {
            putExtra(Intent.EXTRA_RETURN_RESULT, true)
        }
        try {
            uninstallLauncher.launch(uninstallIntent)
        } catch (_: Throwable) {
            val fallbackIntent = Intent(Intent.ACTION_UNINSTALL_PACKAGE).apply {
                data = Uri.parse("package:$targetPkgName")
                putExtra(Intent.EXTRA_RETURN_RESULT, true)
            }
            uninstallLauncher.launch(fallbackIntent)
        }
    }

    private fun executeSystemInstall(file: File) {
        executeNormalInstall(file)
    }

    private fun executeNormalInstall(file: File) {
        // فحص التوقيع قبل التثبيت
        try {
            val pm = packageManager
            val pkgInfo = pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNATURES)
            val signatures = pkgInfo?.signatures
            if (signatures.isNullOrEmpty()) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("⚠️ ملف غير موقع")
                    .setMessage("هذا التطبيق غير موقع ولن يقبله النظام للتثبيت.\n\nهل تريد تفعيل باتش التوقيع وإعادة معالجة التطبيق الآن؟")
                    .setPositiveButton("✍️ توقيع الملف") { _, _ ->
                        // توقيع الملف مباشرة دون إعادة المعالجة
                        viewModel.signFileOnly(file)
                        Toast.makeText(this, "🚀 جاري توقيع الملف الناتج مباشرة...", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("فهمت", null)
                    .show()
                return
            }
        } catch (e: Exception) {
            android.util.Log.e("InstallCheck", "Error checking signature", e)
        }

        try {
            val stagedFile = File(cacheDir, "install_${file.name}")
            file.copyTo(stagedFile, overwrite = true)
            val uri = FileProvider.getUriForFile(
                this,
                "${BuildConfig.APPLICATION_ID}.fileprovider",
                stagedFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح نافذة التثبيت: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareApk(file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "${BuildConfig.APPLICATION_ID}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "مشاركة ملف APK المعدل"))
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر مشاركة الملف: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------
    // نافذة عن التطبيق والحقوق
    // ---------------------------------------------------------
    private fun showAboutDialog() {
        val message = """
            EDITOR TRUE
            أداة تعديل تطبيقات أندرويد الاحترافية
            الإصدار: ${BuildConfig.VERSION_NAME}

            التطوير: محمود عادل

            قناتي على تيليجرام:
            https://t.me/editortrue

            قناتي على يوتيوب:
            https://youtube.com/@editortrue

            جميع الحقوق محفوظة © ${java.time.LocalDate.now().year}
        """.trimIndent()
        MaterialAlertDialogBuilder(this)
            .setTitle("ℹ️ عن التطبيق")
            .setMessage(message)
            .setPositiveButton("تيليجرام") { _, _ ->
                openUrl("https://t.me/editortrue")
            }
            .setNeutralButton("يوتيوب") { _, _ ->
                openUrl("https://youtube.com/@editortrue")
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showModifiedAppsDialog() {
        // الفحص من نفس المسار الذي تحفظ فيه الخدمة، خارج Download تماماً.
        val editorTrueFolder = File("/storage/emulated/0/EDITOR TRUE")
        val files = editorTrueFolder.listFiles()
            ?.asSequence()
            ?.filter { it.isFile && it.extension.equals("apk", ignoreCase = true) }
            ?.distinctBy { it.absolutePath }
            ?.sortedByDescending { it.lastModified() }
            ?.toList()
            ?: emptyList()

        if (files.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("📂 التطبيقات المعدلة")
                .setMessage("لا توجد أي تطبيقات معدلة محفوظة حتى الآن في مجلد EDITOR TRUE.")
                .setPositiveButton("إغلاق", null)
                .show()
            return
        }

        val names = files.map { "${it.name}\n(${viewModel.humanBytes(it.length())} — ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(it.lastModified()))})" }.toTypedArray()

        MaterialAlertDialogBuilder(this)
            .setTitle("📂 التطبيقات المعدلة (${files.size})")
            .setItems(names) { _, which ->
                val selectedFile = files[which]
                showSelectedModifiedAppActionDialog(selectedFile)
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showSelectedModifiedAppActionDialog(file: File) {
        val options = arrayOf("📥 تثبيت التطبيق", "📤 مشاركة الملف", "🗑️ حذف التطبيق نهائياً")
        MaterialAlertDialogBuilder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> installApk(file)
                    1 -> shareApk(file)
                    2 -> {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("تأكيد الحذف")
                            .setMessage("هل أنت متأكد من حذف ${file.name}؟")
                            .setPositiveButton("حذف") { _, _ ->
                                if (file.delete()) {
                                    Toast.makeText(this, "✔ تم الحذف بنجاح", Toast.LENGTH_SHORT).show()
                                    // إعادة فتح القائمة المحدثة
                                    showModifiedAppsDialog()
                                } else {
                                    Toast.makeText(this, "❌ فشل الحذف", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .setNegativeButton("إلغاء", null)
                            .show()
                    }
                }
            }
            .setNegativeButton("رجوع", null)
            .show()
    }


}
